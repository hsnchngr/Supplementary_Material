"""Two-level erbium physics: z-resolved reference solver (plant), reduced reservoir model (twin core), fibre SRS.

All amplifiers advance in parallel per time step, so a batch of independent scenarios and a
multi-span chain use the same code path. Fibre delay is at least one step, hence no same-step coupling.
Units: W, m, s. Gains in linear scale unless the name ends in _db.
"""
import numpy as np

H = 6.62607015e-34
C0 = 299792458.0
KT_EV = 0.0259
HC_EV_NM = 1239.84


def grid(band="C", K=95):
    """Channel frequencies in Hz. C reproduces the COSMOS grid; L is an adjacent simulated band of 80 channels."""
    if band == "C":
        return 191.35e12 + 50e9 * np.arange(K)
    return 187.30e12 + 50e9 * np.arange(K)


def sigma_e(lam_nm):
    g = lambda c, w: np.exp(-((lam_nm - c) / w) ** 2)
    return 1e-25 * (3.1 * g(1530.0, 5.2) + 2.75 * g(1548.0, 22.0) + 1.05 * g(1585.0, 26.0))


def sigma_a(lam_nm):
    """McCumber relation with crossover at 1530 nm."""
    return sigma_e(lam_nm) * np.exp(HC_EV_NM * (1 / lam_nm - 1 / 1530.0) / KT_EV)


class AmpParams:
    """Stage parameters for a set of A amplifiers with K channels (arrays broadcast on A)."""

    def __init__(self, A, band="C", L=None, Nt=4.0e24, tau=10.5e-3, gamma_s=0.70, gamma_p=0.75,
                 a_core=5.3e-12, sig_p=2.5e-25, alpha_bg=0.01, K=95, seed_scale=None):
        self.A, self.K, self.band = A, K, band
        self.nu = np.tile(grid(band, K), (A, 1))
        lam = C0 / self.nu * 1e9
        self.sa = sigma_a(lam)
        self.se = sigma_e(lam)
        self.L = np.full(A, (14.0 if band == "C" else 95.0) if L is None else L, float)
        self.Nt = np.full(A, Nt, float)
        self.tau = np.full(A, tau, float)
        self.gs = np.full(A, gamma_s, float)
        self.gp = np.full(A, gamma_p, float)
        self.a = np.full(A, a_core, float)
        self.sp = np.full(A, sig_p, float)
        self.nu_p = C0 / 980e-9
        self.alpha_bg = alpha_bg
        self.eta = np.ones(A)  # pump coupling efficiency
        self.gff_db = np.zeros((A, K))

    def perturb(self, rng, s=1.0):
        """Device to device spread: the source of parametric mismatch between plant and nominal twin."""
        A = self.A
        self.tau *= 1 + s * 0.08 * rng.standard_normal(A)
        self.Nt *= 1 + s * 0.04 * rng.standard_normal(A)
        self.L *= 1 + s * 0.03 * rng.standard_normal(A)
        self.eta *= 1 + s * 0.06 * rng.standard_normal(A)
        self.gs *= 1 + s * 0.02 * rng.standard_normal(A)
        return self


class ZSolver:
    """Giles and Desurvire two-level solver, co-pumped at 980 nm, with forward and backward ASE bins."""

    def __init__(self, p, Nz=12, nbins=7, use_ase=True):
        self.p, self.Nz, self.use_ase = p, Nz, use_ase
        A, K = p.A, p.K
        self.dz = (p.L / Nz)[:, None]
        idx = np.linspace(0, K - 1, nbins).round().astype(int)
        self.bin_idx = idx
        self.bw = K * 50e9 / nbins
        self.n = np.full((A, Nz), 0.6)
        self.ase_b = np.zeros((A, nbins, Nz + 1))
        self.ase_out = np.zeros((A, nbins))
        self.gs_a = (p.gs * p.Nt)[:, None] * p.sa
        self.gs_e = (p.gs * p.Nt)[:, None] * p.se
        self.gp_a = p.gp * p.Nt * p.sp
        self.vol = (p.Nt * p.a * p.L / Nz)
        self.ph_s = 1 / (H * p.nu)
        self.ph_p = 1 / (H * p.nu_p)

    def step(self, Pin, Pp, dt):
        """Advance the inversion by dt. Pin: (A,K) W at the EDF input. Pp: (A,) W launched pump."""
        p, Nz, n = self.p, self.Nz, self.n
        A = p.A
        dz = self.dz
        aS = self.gs_a * dz + p.alpha_bg * dz
        eaS = (self.gs_a + self.gs_e) * dz
        S = Pin.copy()
        Q = Pp * p.eta
        flux = np.zeros((A, Nz))
        lam = np.zeros((A, Nz))  # d(flux)/dn estimate for the linearly implicit update
        idx = self.bin_idx
        if self.use_ase:
            aA, eaA, sp = aS[:, idx], eaS[:, idx], 2 * H * p.nu[:, idx] * self.bw * self.gs_e[:, idx] * dz
            ph_A = self.ph_s[:, idx]
            F = np.zeros((A, len(idx)))
            # backward ASE from the previous inversion profile
            B = self.ase_b
            for i in range(Nz - 1, -1, -1):
                G = np.exp(eaA * n[:, i, None] - aA)
                stim = B[:, :, i + 1] * (1 - G)
                B[:, :, i] = B[:, :, i + 1] * G + sp * n[:, i, None]
                flux[:, i] = (stim * ph_A).sum(1)
                lam[:, i] = (B[:, :, i + 1] * G * eaA * ph_A).sum(1)
        gp_dz = self.gp_a * dz[:, 0]
        for i in range(Nz):
            ni = n[:, i]
            G = np.exp(eaS * ni[:, None] - aS)
            flux[:, i] += (S * (1 - G) * self.ph_s).sum(1)
            lam[:, i] += (S * G * eaS * self.ph_s).sum(1)
            S = S * G
            Gp = np.exp(-gp_dz * (1 - ni))
            flux[:, i] += Q * (1 - Gp) * self.ph_p
            lam[:, i] += Q * Gp * gp_dz * self.ph_p
            Q = Q * Gp
            if self.use_ase:
                G = np.exp(eaA * ni[:, None] - aA)
                flux[:, i] += (F * (1 - G) * ph_A).sum(1)
                lam[:, i] += (F * G * eaA * ph_A).sum(1)
                F = F * G + sp * ni[:, None]
        if self.use_ase:
            self.ase_out = F
        dn = -n / p.tau[:, None] + flux / self.vol[:, None]
        rate = 1 / p.tau[:, None] + lam / self.vol[:, None]
        self.n = np.clip(n + dt * dn / (1 + dt * rate), 0.0, 1.0)
        return S  # (A,K) signal at the EDF output before the GFF

    def gain_db(self, Pin):
        """Signal gain including the GFF, for current inversion, no state change."""
        p = self.p
        nbar = self.n.mean(1, keepdims=True)
        tot = (self.gs_a + self.gs_e) * p.L[:, None] * nbar - (self.gs_a + p.alpha_bg) * p.L[:, None]
        return 4.343 * tot - p.gff_db

    def nbar(self):
        return self.n.mean(1)

    def nf_db(self):
        """Noise figure per channel from the local inversion at the input side of the fibre."""
        p = self.p
        n1 = self.n[:, : max(2, self.Nz // 4)].mean(1, keepdims=True)
        nsp = p.se * n1 / np.maximum(p.se * n1 - p.sa * (1 - n1), 1e-30)
        return 10 * np.log10(2 * np.maximum(nsp, 1.0))


def settle(sol, Pin, Pp, T=0.04, dt=10e-6):
    """March to steady state with a coarse step for initial conditions."""
    for _ in range(int(T / dt)):
        sol.step(Pin, Pp, dt)
    return sol


def design_gff(p, target_db, Pin, Pp0=None, band_mean=True):
    """Find full load pump and a GFF that flatten the stage at target_db. Returns the pump in W."""
    A = p.A
    nd = 0.68 if p.band == "C" else 0.50
    lo, hi = np.full(A, 1e-3), np.full(A, 1.5)
    sol = ZSolver(p)
    for _ in range(9):  # bisection on pump power for the design inversion
        pump = np.sqrt(lo * hi)
        settle(sol, Pin, pump, T=0.008)
        up = sol.nbar() < nd
        lo, hi = np.where(up, pump, lo), np.where(up, hi, pump)
    pump = np.sqrt(lo * hi)
    settle(sol, Pin, pump, T=0.03)
    p.gff_db = sol.gain_db(Pin) + p.gff_db - target_db
    return pump, sol.n.copy()


class ReservoirModel:
    """Reduced twin core: Saleh style photon balance for the mean inversion, ASE neglected.

    dn/dT = -n/tau + [ sum_k P_k (1-G_k)/(h nu_k) + eta Pp (1-G_p)/(h nu_p) ] / (Nt a L)
    """

    def __init__(self, p):
        self.p = p
        self.ea = (p.gs * p.Nt * p.L)[:, None] * (p.sa + p.se)
        self.aa = (p.gs * p.Nt * p.L)[:, None] * p.sa + p.alpha_bg * p.L[:, None]
        self.ap = p.gp * p.Nt * p.L * p.sp
        self.ph = 1 / (H * p.nu)
        self.php = 1 / (H * p.nu_p)
        self.vol = p.Nt * p.a * p.L

    def f(self, n, Pin, Pp):
        G = np.exp(np.clip(self.ea * n[:, None] - self.aa, -30, 30))
        Gp = np.exp(-self.ap * (1 - n))
        flux = (Pin * (1 - G) * self.ph).sum(1) + self.p.eta * Pp * (1 - Gp) * self.php
        return -n / self.p.tau + flux / self.vol

    def gain_db(self, n):
        return 4.343 * (self.ea * n[:, None] - self.aa) - self.p.gff_db

    def n_from_gain(self, g_db, mask):
        """Invert the measured mean gain over active channels for the mean inversion."""
        e = 4.343 * self.ea
        a = 4.343 * self.aa + self.p.gff_db
        w = mask.astype(float)
        return ((g_db * w).sum(1) + (a * w).sum(1)) / np.maximum((e * w).sum(1), 1e-9)


def srs_span(P, nu, alpha_db_km=0.2, L_km=80.0, cr=0.42e-13 * 1e-3 * 1e15 / 1e15, Aeff=None):
    """Closed form SRS tilt with a triangular gain slope (Zirngibl). P (A,N) W at span input.

    cr is the Raman gain slope in 1/(W m Hz). Power is conserved up to the common fibre loss.
    """
    a = alpha_db_km / 4.343e3
    Leff = (1 - np.exp(-a * L_km * 1e3)) / a
    f = (nu - nu.mean(1, keepdims=True))
    Pt = P.sum(1, keepdims=True)
    w = np.exp(np.clip(-cr * Leff * Pt * f, -20, 20))
    norm = (P * w).sum(1, keepdims=True) / np.maximum(Pt, 1e-15)
    return P * np.exp(-a * L_km * 1e3) * w / np.maximum(norm, 1e-15)
