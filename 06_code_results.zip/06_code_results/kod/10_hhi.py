"""Cross testbed check on Fraunhofer HHI EDFA Dataset 01: models trained only on COSMOS, calibrated with K spectra of the HHI amplifiers.

HHI powers are read at coupler ports, so every channel carries a static, unknown coupler offset. All compared methods learn it
from the calibration spectra, which is why only calibrated (K >= 1) errors are meaningful for absolute gain.
"""
import os, sys, json, hashlib, importlib.util as iu
os.environ.setdefault("OMP_NUM_THREADS", "4")
import numpy as np, pandas as pd, torch
sp = iu.spec_from_file_location("st", "kod/02_steady.py"); st = iu.module_from_spec(sp); sp.loader.exec_module(st)
torch.set_num_threads(4)
ROOT = "data/hhi/edfa/x/edfa dataset 01"
KS = [1, 2, 4, 8, 16, 32]
REPS = 10


def load_hhi():
    A = pd.read_csv(f"{ROOT}/amplifier_1000_samples.csv"); Cf = pd.read_csv(f"{ROOT}/channel_config_1000_samples.csv").sort_values("sample_id")
    f = np.array(A.columns[2:], float)
    idx = np.round((f - 191.35) / 0.05).astype(int)  # COSMOS channel index of each HHI channel
    mask92 = Cf.iloc[:, 1:].values.astype(bool)
    P = {p: A[A.point == p].sort_values("sample_id").iloc[:, 2:].values for p in range(1, 6)}
    out = {}
    # booster: P1 -> P2; preamplifier: P3 -> P5 (through port). The 18 dB tap at P3 is added so input powers sit in the COSMOS range.
    for typ, a, b, off in (("booster", 1, 2, 0.0), ("preamp", 3, 5, 18.0)):
        n = len(mask92)
        pin = np.full((n, 95), -50.0, np.float32); pout = np.full((n, 95), -50.0, np.float32); mask = np.zeros((n, 95), bool)
        pin[:, idx] = P[a] + off; pout[:, idx] = P[b] + off; mask[:, idx] = mask92
        lin = 10 ** (pin / 10) * mask
        cfg = np.array([int(hashlib.md5(m.tobytes()).hexdigest()[:8], 16) for m in mask], np.int64)
        out[typ] = dict(pin=pin, pout=pout, mask=mask, ptin=(10 * np.log10(lin.sum(1))).astype(np.float32), cfg=cfg, gt=np.zeros(n, np.float32))
    return out


def fleet(typ):
    """Twin, core and MLP trained on all eight COSMOS devices of the type, the same recipe as the leave one device out runs."""
    cache = f"sonuclar/hhi_fleet_{typ}.pt"
    D = st.load(f"data/parsed_{typ}.npz")
    tr = st.sub(D, np.where(~st.is_test(D["cfg"]))[0])
    core = st.fit_core(tr)
    if os.path.exists(cache):
        s = torch.load(cache)
        hyb, mlp = [], []
        for sd in s["hyb"]:
            n = st.Net(); n.load_state_dict(sd); n.eval(); hyb.append(n)
        for sd in s["mlp"]:
            n = st.Net(); n.load_state_dict(sd); n.eval(); mlp.append(n)
        return core, hyb, mlp
    c_tr = st.core_predict(core, tr); X = st.features(tr); G = st.gains(tr)
    R = G - c_tr
    for dv in np.unique(tr["dev"]):
        for sg in np.unique(tr["gt"]):
            j = (tr["dev"] == dv) & (tr["gt"] == sg); mm = tr["mask"][j].astype(float)
            R[j] -= (R[j] * mm).sum(0) / (mm.sum(0) + 1.0)
    Pw = torch.as_tensor(np.where(tr["mask"], 10 ** ((tr["pin"] - tr["ptin"][:, None]) / 10), 0).astype(np.float32))
    hyb = [st.train(X, R, tr["mask"], 300 + i, lam_c=0.2, ctx=Pw) for i in range(5)]
    mlp = [st.train(X, G - tr["gt"][:, None], tr["mask"], 400 + i) for i in range(2)]
    torch.save(dict(hyb=[n.state_dict() for n in hyb], mlp=[n.state_dict() for n in mlp]), cache)
    return core, hyb, mlp


def with_gt(d, s):
    e = dict(d); e["gt"] = np.full(len(d["gt"]), s, np.float32); return e


def pick_setting(core, hyb, cal):
    """The HHI gain setting is not published: choose the COSMOS setting whose load response best explains the calibration spectra."""
    best = None
    for s in sorted(core):
        c = with_gt(cal, s)
        p = st.core_predict(core, c) + st.predict(hyb, st.features(c)).mean(0)
        r = st.gains(c) - p; m = c["mask"].astype(float)
        db = st.bias_update(r, m)
        err = float((np.abs(r - db) * m).sum() / m.sum()) if m.sum() else 0.0
        if len(cal["gt"]) == 1: err = 0.0 if s == 18.0 else 1.0  # one spectrum cannot reveal the load response
        if best is None or err < best[0]: best = (err, s)
    return best[1]


def run(typ):
    H = load_hhi()[typ]
    core, hyb, mlp = fleet(typ)
    test_mask = st.is_test(H["cfg"]) | st.is_conf(H["cfg"])  # 30% of the configurations are never used for calibration
    te_i = np.where(test_mask)[0]; pool = np.where(~test_mask)[0]
    n_act = H["mask"][te_i].sum(1)
    bins = [(1, 21), (21, 41), (41, 61), (61, 81), (81, 93)]
    res = {}
    for K in KS:
        acc = {m: [] for m in ("twin", "core", "mlp", "static")}
        accb = {m: [] for m in acc}
        sel_s = []
        for rep in range(REPS):
            rng = np.random.default_rng(1000 * K + rep)
            ci = st.calib_sets(pool, H, rng, K)
            s = pick_setting(core, hyb, st.sub(H, ci)); sel_s.append(s)
            ca, te = with_gt(st.sub(H, ci), s), with_gt(st.sub(H, te_i), s)
            Gc, Gt = st.gains(ca), st.gains(te); mc, mt = ca["mask"].astype(float), te["mask"]
            # twin
            pc = st.core_predict(core, ca) + st.predict(hyb, st.features(ca)).mean(0)
            pt = st.core_predict(core, te) + st.predict(hyb, st.features(te)).mean(0) + st.bias_update(Gc - pc, mc)
            # physics core only
            pcc = st.core_predict(core, ca); ptc = st.core_predict(core, te) + st.bias_update(Gc - pcc, mc)
            # MLP transfer learning: COSMOS pre-trained, fine tuned on the K spectra
            # the MLP gets the same per channel offset calibration first, then the usual fine tuning on what is left
            pm0 = ca["gt"][:, None] + st.predict(mlp, st.features(ca)).mean(0)
            dbm = st.bias_update(Gc - pm0, mc)
            ft = [st.finetune(n, st.features(ca), Gc - dbm - ca["gt"][:, None], ca["mask"], steps=150) for n in mlp]
            ptm = te["gt"][:, None] + st.predict(ft, st.features(te)).mean(0) + dbm
            # static spectrum: per channel mean of the calibration gains, no load model at all
            pts = np.broadcast_to(st.bias_update(Gc - 0.0, mc), Gt.shape)
            for name, p in (("twin", pt), ("core", ptc), ("mlp", ptm), ("static", pts)):
                e = np.abs(p - Gt)
                acc[name].append(float(e[mt].mean()))
                accb[name].append([float(e[(n_act >= lo) & (n_act < hi)][mt[(n_act >= lo) & (n_act < hi)]].mean()) for lo, hi in bins])
        res[K] = {m: dict(mae=float(np.mean(v)), sd=float(np.std(v)), bins=np.mean(accb[m], 0).tolist()) for m, v in acc.items()}
        res[K]["setting"] = {str(s): sel_s.count(s) for s in set(sel_s)}
        print(typ, K, {m: round(res[K][m]["mae"], 3) for m in acc}, res[K]["setting"], flush=True)
    # 90% intervals: conformal scale from 16 calibration spectra of the HHI device, coverage on the held out configurations
    rng = np.random.default_rng(7)
    ci = st.calib_sets(pool, H, rng, 32)
    s = pick_setting(core, hyb, st.sub(H, ci[:16]))
    a, b, te = with_gt(st.sub(H, ci[:16]), s), with_gt(st.sub(H, ci[16:]), s), with_gt(st.sub(H, te_i), s)
    pa = st.core_predict(core, a) + st.predict(hyb, st.features(a)).mean(0); db = st.bias_update(st.gains(a) - pa, a["mask"].astype(float))
    Rb = st.predict(hyb, st.features(b)); pb = st.core_predict(core, b) + Rb.mean(0) + db
    q = st.conformal(pb - st.gains(b), Rb.std(0), b["mask"])
    Rt = st.predict(hyb, st.features(te)); ptt = st.core_predict(core, te) + Rt.mean(0) + db
    inside = np.abs(ptt - st.gains(te)) <= q * (Rt.std(0) + 0.02)
    res["coverage90"] = float(inside[te["mask"]].mean()); res["width90"] = float((2 * q * (Rt.std(0) + 0.02))[te["mask"]].mean())
    res["n_test"] = int(len(te_i)); res["n_pool"] = int(len(pool)); res["bins"] = bins
    print(typ, "coverage", round(res["coverage90"], 3), "width", round(res["width90"], 3), flush=True)
    return res


if __name__ == "__main__":
    out = {t: run(t) for t in ("booster", "preamp")}
    json.dump(out, open("sonuclar/hhi.json", "w"), indent=1)
