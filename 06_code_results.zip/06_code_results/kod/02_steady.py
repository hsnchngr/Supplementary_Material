"""Tier 1: steady state twin on measured COSMOS data, leave one device out, leak free configuration split."""
import os, sys, json, time, copy
os.environ.setdefault("OMP_NUM_THREADS", "2"); os.environ.setdefault("MKL_NUM_THREADS", "2")
import numpy as np, torch, torch.nn as nn
from multiprocessing import get_context
torch.set_num_threads(2)
KS = [0, 1, 2, 5, 10, 20, 50]


def load(path):
    d = np.load(path)
    return {k: d[k] for k in d.files}


def sub(d, i):
    return {k: v[i] for k, v in d.items()}


def gains(d):
    return d["pout"] - d["pin"]


def is_test(cfg): return (cfg % 10) < 2
def is_conf(cfg): return (cfg % 10) == 2


def fit_core(d, iters=5):
    """g_k = b_k + D_k x per gain setting: dynamic gain tilt prior, ALS on active channels only."""
    core = {}
    g, m = gains(d), d["mask"]
    for s in np.unique(d["gt"]):
        i = d["gt"] == s
        gi, mi = g[i].astype(np.float64), m[i].astype(np.float64)
        b = (gi * mi).sum(0) / np.maximum(mi.sum(0), 1)
        D = np.ones(95)
        for _ in range(iters):
            x = (((gi - b) * D * mi).sum(1)) / np.maximum((D * D * mi).sum(1), 1e-6)
            xm = (x[:, None] * mi).sum(0) / np.maximum(mi.sum(0), 1)
            gm = (gi * mi).sum(0) / np.maximum(mi.sum(0), 1)
            cov = ((x[:, None] - xm) * (gi - gm) * mi).sum(0)
            var = (((x[:, None] - xm) ** 2) * mi).sum(0) + 1e-6
            D = cov / var
            D = D / max(D.mean(), 1e-6)
            b = gm - D * xm
        pti = 10 * np.log10((10 ** (d["pout"][i] / 10) * m[i]).sum(1) / (10 ** (d["pin"][i] / 10) * m[i]).sum(1))
        core[float(s)] = dict(b=b, D=D, delta=float(np.median(pti - s)))
    return core


def core_predict(core, d, db=None):
    """Hard constant gain constraint: x solves total output power over total input power = target + delta."""
    n = len(d["gt"]); out = np.zeros((n, 95))
    for s in np.unique(d["gt"]):
        c = core[float(s)]; i = np.where(d["gt"] == s)[0]
        b = c["b"] + (0 if db is None else db); D = c["D"]
        m = d["mask"][i].astype(float); pl = 10 ** (d["pin"][i] / 10) * m
        T = s + c["delta"]; x = np.zeros(len(i))
        for _ in range(4):
            g = b + D * x[:, None]; po = pl * 10 ** (g / 10)
            f = 10 * np.log10(po.sum(1) / pl.sum(1)) - T
            dd = (po * D).sum(1) / po.sum(1)
            x = x - f / np.maximum(dd, 0.05)
        out[i] = b + D * x[:, None]
    return out


def features(d):
    m = d["mask"].astype(np.float32)
    p = np.where(d["mask"], (d["pin"] - d["ptin"][:, None]) / 10 + 2, 0)
    return np.concatenate([m, p, d["gt"][:, None] / 30 - 0.7, d["ptin"][:, None] / 15], 1).astype(np.float32)


class Net(nn.Module):
    def __init__(s, ni=192, w=256):
        super().__init__()
        s.f = nn.Sequential(nn.Linear(ni, w), nn.GELU(), nn.Linear(w, w), nn.GELU(), nn.Linear(w, 95))

    def forward(s, x): return s.f(x)


def train(X, Y, M, seed, steps=5000, lr=1.5e-3, lam_c=0.0, ctx=None):
    torch.manual_seed(seed); net = Net()
    X, Y, M = torch.as_tensor(X), torch.as_tensor(Y.astype(np.float32)), torch.as_tensor(M.astype(np.float32))
    opt = torch.optim.AdamW(net.parameters(), lr=lr, weight_decay=1e-5)
    sch = torch.optim.lr_scheduler.CosineAnnealingLR(opt, steps)
    for t in range(steps):
        idx = torch.randint(0, len(X), (512,))
        out = net(X[idx])
        e = (out - Y[idx]) * M[idx]
        loss = (e ** 2).sum() / M[idx].sum()
        if lam_c > 0:  # conservation penalty: the residual must not shift the mean power gain
            pw = ctx[idx]
            loss = loss + lam_c * (((out * pw).sum(1) / pw.sum(1)) ** 2).mean()
        opt.zero_grad(); loss.backward(); opt.step(); sch.step()
    net.eval(); return net


@torch.no_grad()
def predict(nets, X):
    X = torch.as_tensor(X)
    return np.stack([n(X).numpy() for n in nets])


def metrics(p, y, m, gt):
    e = (p - y)[m]; rip = (y - gt[:, None])[m]
    return dict(mae=float(np.abs(e).mean()), rmse=float(np.sqrt((e ** 2).mean())),
                r2=float(1 - (e ** 2).sum() / ((rip - rip.mean()) ** 2).sum()), p95=float(np.percentile(np.abs(e), 95)))


def calib_sets(pool_idx, d, rng, K):
    """Calibration always includes a full load measurement if one exists, then random configurations."""
    if K == 0: return np.array([], int)
    n = d["mask"][pool_idx].sum(1)
    first = pool_idx[np.argmax(n)]  # the most fully loaded spectrum available, normally the full load
    rest = rng.permutation(pool_idx[pool_idx != first])[: K - 1]
    return np.concatenate([[first], rest])


def smooth(v, w=5):
    k = np.ones(w) / w; pad = np.pad(v, w // 2, mode="edge")
    return np.convolve(pad, k, "valid")


def bias_update(res, m, lam=0.5):
    """Ridge estimate of the device gain offset per channel, with spectral smoothing for sparse load."""
    db = (res * m).sum(0) / np.maximum(m.sum(0), 1)
    glob = (res * m).sum() / max(m.sum(), 1)
    wt = m.sum(0) / (m.sum(0) + lam)  # channels seen in few spectra lean on the band average
    return smooth(wt * db + (1 - wt) * glob)


def finetune(net, X, Y, M, steps=60, lr=3e-4):
    n = copy.deepcopy(net); n.train()
    X, Y, M = torch.as_tensor(X), torch.as_tensor(Y.astype(np.float32)), torch.as_tensor(M.astype(np.float32))
    o = torch.optim.Adam(n.parameters(), lr=lr)
    for _ in range(steps):
        loss = (((n(X) - Y) * M) ** 2).sum() / M.sum(); o.zero_grad(); loss.backward(); o.step()
    n.eval(); return n


def conformal(res, sig, m, alpha=0.1):
    s = (np.abs(res) / (sig + 0.02))[m]
    return float(np.quantile(s, min(1, (1 - alpha) * (1 + 1 / len(s)))))


def fold(args):
    typ, dev, seed = args
    D = load(f"data/parsed_{typ}.npz")
    isdev = D["dev"] == dev
    tr_i = np.where(~isdev & ~is_test(D["cfg"]) & ~is_conf(D["cfg"]))[0]
    cf_i = np.where(~isdev & is_conf(D["cfg"]))[0]
    te_i = np.where(isdev & is_test(D["cfg"]))[0]
    pool = np.where(isdev & ~is_test(D["cfg"]))[0]
    tr, cf, te = sub(D, tr_i), sub(D, cf_i), sub(D, te_i)
    core = fit_core(tr)
    c_tr, c_cf, c_te = core_predict(core, tr), core_predict(core, cf), core_predict(core, te)
    Xtr, Xcf, Xte = features(tr), features(cf), features(te)
    Gtr, Gcf, Gte = gains(tr), gains(cf), gains(te)
    # the residual must describe load dependence, not fleet offsets: remove each training device's own mean per setting
    Rtr = Gtr - c_tr
    for dv in np.unique(tr["dev"]):
        for sg in np.unique(tr["gt"]):
            j = (tr["dev"] == dv) & (tr["gt"] == sg)
            mm = tr["mask"][j].astype(float)
            Rtr[j] -= (Rtr[j] * mm).sum(0) / (mm.sum(0) + 1.0)
    Ptr = np.where(tr["mask"], 10 ** ((tr["pin"] - tr["ptin"][:, None]) / 10), 0).astype(np.float32)
    t0 = time.time()
    hyb = [train(Xtr, Rtr, tr["mask"], seed + i, lam_c=0.2, ctx=torch.as_tensor(Ptr)) for i in range(5)]
    hyb_nc = [train(Xtr, Rtr, tr["mask"], seed + 10)]
    mlp = [train(Xtr, Gtr - tr["gt"][:, None], tr["mask"], seed + 20 + i) for i in range(2)]
    tt = time.time() - t0
    R = dict(typ=typ, dev=dev, train_s=tt, by_k={}, n_test=int(len(te_i)), n_train=int(len(tr_i)))
    Rh = predict(hyb, Xte); ph0 = c_te + Rh.mean(0); sig = Rh.std(0)
    Rcf = predict(hyb, Xcf); pcf = c_cf + Rcf.mean(0); scf = Rcf.std(0)
    q0 = conformal(pcf - Gcf, scf, cf["mask"])
    pmlp0 = te["gt"][:, None] + predict(mlp, Xte).mean(0)
    pnc0 = c_te + predict(hyb_nc, Xte).mean(0)
    R["core"] = metrics(c_te, Gte, te["mask"], te["gt"])
    R["nc_zero"] = metrics(pnc0, Gte, te["mask"], te["gt"])
    R["cov_zero"] = float((np.abs(ph0 - Gte) <= q0 * (sig + 0.02))[te["mask"]].mean())
    R["width_zero"] = float((2 * q0 * (sig + 0.02))[te["mask"]].mean())
    rng = np.random.default_rng(seed)
    avg = lambda L: {k: float(np.mean([x[k] for x in L])) for k in L[0]}
    for K in KS:
        hm, mm, cm = [], [], []
        for rep in range(1 if K == 0 else 3):
            if K == 0:
                hm.append(metrics(ph0, Gte, te["mask"], te["gt"])); mm.append(metrics(pmlp0, Gte, te["mask"], te["gt"]))
                cm.append(metrics(c_te, Gte, te["mask"], te["gt"])); continue
            ca = sub(D, calib_sets(pool, D, rng, K))
            pcc = core_predict(core, ca)
            pc = pcc + predict(hyb, features(ca)).mean(0)
            hm.append(metrics(ph0 + bias_update(gains(ca) - pc, ca["mask"].astype(float)), Gte, te["mask"], te["gt"]))
            cm.append(metrics(c_te + bias_update(gains(ca) - pcc, ca["mask"].astype(float)), Gte, te["mask"], te["gt"]))
            ft = [finetune(n, features(ca), gains(ca) - ca["gt"][:, None], ca["mask"]) for n in mlp]
            mm.append(metrics(te["gt"][:, None] + predict(ft, Xte).mean(0), Gte, te["mask"], te["gt"]))
        R["by_k"][K] = dict(hybrid=avg(hm), mlp=avg(mm), core=avg(cm))
    # 20 points for the offset, 20 fresh ones for the local conformal quantile
    perm = rng.permutation(pool)
    full = pool[D["mask"][pool].sum(1) == 95][:1]
    a = sub(D, np.concatenate([full, perm[:19]])); b = sub(D, perm[19:39])
    pa = core_predict(core, a) + predict(hyb, features(a)).mean(0); db = bias_update(gains(a) - pa, a["mask"].astype(float))
    Rb = predict(hyb, features(b)); pb = core_predict(core, b) + Rb.mean(0) + db
    q1 = conformal(pb - gains(b), Rb.std(0), b["mask"])
    p1 = ph0 + db
    R["cov_few"] = float((np.abs(p1 - Gte) <= q1 * (sig + 0.02))[te["mask"]].mean())
    R["width_few"] = float((2 * q1 * (sig + 0.02))[te["mask"]].mean())
    levels = np.linspace(0.05, 0.95, 19); rel = []
    for lv in levels:
        qq = conformal(pb - gains(b), Rb.std(0), b["mask"], alpha=1 - lv)
        rel.append(float((np.abs(p1 - Gte) <= qq * (sig + 0.02))[te["mask"]].mean()))
    R["rel_levels"] = levels.tolist(); R["rel_cov"] = rel
    t = time.perf_counter()
    for _ in range(200): predict(hyb[:1], Xte[:1])
    R["infer_ms"] = (time.perf_counter() - t) / 200 * 1e3
    # external tests on the same device: remeasurement (about 6 months later) and the 2026 campaign
    for name in ("remeas", "live2026"):
        E = load(f"data/parsed_{name}.npz")
        i = np.where((E["dev"] == dev) & (E["typ"] == typ) & np.isin(E["gt"], list(core.keys())))[0]
        if len(i) < 30: continue
        Ei = sub(E, i); tst = (Ei["cfg"] % 2 == 0)
        Et = sub(Ei, np.where(tst)[0])
        pe = core_predict(core, Et) + predict(hyb, features(Et)).mean(0)
        Ge = gains(Et); rec = dict(n=int(len(Et["gt"])), zero=metrics(pe, Ge, Et["mask"], Et["gt"]))
        pl = np.where(~tst)[0]
        if len(pl) >= 20:
            c = sub(Ei, rng.permutation(pl)[:20])
            pc = core_predict(core, c) + predict(hyb, features(c)).mean(0)
            rec["few20"] = metrics(pe + bias_update(gains(c) - pc, c["mask"].astype(float)), Ge, Et["mask"], Et["gt"])
        R[name] = rec
    ex = {}
    cnt = te["mask"].sum(1)
    for s, name, cond in ((18.0, "full", cnt == 95), (18.0, "half", (cnt > 40) & (cnt < 60)), (18.0, "sparse", cnt < 12)):
        j = np.where((te["gt"] == s) & cond)[0]
        if len(j):
            j = j[0]
            ex[name] = dict(y=np.where(te["mask"][j], Gte[j], np.nan).tolist(), p=np.where(te["mask"][j], p1[j], np.nan).tolist(), sig=(q1 * (sig[j] + 0.02)).tolist())
    R["examples"] = ex
    core_out = {str(k): dict(b=v["b"].tolist(), D=v["D"].tolist(), delta=v["delta"]) for k, v in core.items()}
    json.dump(core_out, open(f"sonuclar/core_{typ}_{dev}.json", "w"))
    torch.save([n.state_dict() for n in hyb], f"sonuclar/steady_{typ}_{dev}.pt")
    print(typ, dev, {k: round(R["by_k"][k]["hybrid"]["mae"], 3) for k in (0, 5, 20)}, "mlp", {k: round(R["by_k"][k]["mlp"]["mae"], 3) for k in (0, 5, 20)},
          "core", round(R["core"]["mae"], 3), "cov", round(R["cov_zero"], 3), round(R["cov_few"], 3), "t", int(tt), flush=True)
    return R


if __name__ == "__main__":
    devs = ['rdm1-co1', 'rdm2-co1', 'rdm3-co1', 'rdm4-co1', 'rdm5-co1', 'rdm6-co1', 'rdm1-lg1', 'rdm2-lg1']
    jobs = [(t, d, 100 + i) for t in ("booster", "preamp") for i, d in enumerate(devs)]
    with get_context("spawn").Pool(int(sys.argv[1]) if len(sys.argv) > 1 else 14) as p:
        res = list(p.imap(fold, jobs))
    json.dump(res, open("sonuclar/steady.json", "w"))
