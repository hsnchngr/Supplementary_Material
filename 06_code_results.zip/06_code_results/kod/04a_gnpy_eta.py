"""Run in the GNPy venv: export the GN model eta matrix from GNPy for the C+L grid and verify it on random spectra."""
import sys, numpy as np
from numpy.random import default_rng
from gnpy.core.elements import Fiber
from gnpy.core.info import create_arbitrary_spectral_information
from gnpy.core.parameters import SimParams
from gnpy.core.science_utils import NliSolver, RamanSolver
from gnpy.core.utils import lin2db, db2lin
L_KM = 70.0
fC = 191.35e12 + 50e9 * np.arange(95)
fL = 187.30e12 + 50e9 * np.arange(80)
f = np.concatenate([fL, fC])
B = 32e9
fib = Fiber(uid="s", type_variety="SSMF", params={"length": L_KM, "length_units": "km", "loss_coef": 0.2, "dispersion": 1.67e-5,
    "effective_area": 83e-12, "pmd_coef": 1.265e-15, "con_in": 0, "con_out": 0, "att_in": 0})
SimParams.set_params({"raman_params": {"flag": False}, "nli_params": {"method": "gn_model_analytic"}})
si = create_arbitrary_spectral_information(frequency=f, pch=1e-3, baud_rate=B, slot_width=50e9, tx_osnr=40, tx_power=1e-3, roll_off=0.15)
eta = NliSolver._gn_analytic(si, fib)
srs = RamanSolver.calculate_stimulated_raman_scattering(si, fib)
print("eta", eta.shape, "gamma", fib.gamma(f[50]), "alpha", fib.alpha(f[50]), "beta2", fib.beta2(f[50]))
# verification: GNPy NLI for random powers against P_k sum eta_kj P_j^2
rng = default_rng(0)
errs = []
for t in range(6):
    p = 10 ** (rng.uniform(-3, 1, len(f)) / 10) * 1e-3
    p[rng.random(len(f)) < 0.4] = 1e-9
    s2 = create_arbitrary_spectral_information(frequency=f, pch=p, baud_rate=B, slot_width=50e9, tx_osnr=40, tx_power=p, roll_off=0.15)
    srs2 = RamanSolver.calculate_stimulated_raman_scattering(s2, fib)
    full = NliSolver.compute_nli(s2, srs2, fib)
    mine = p * (NliSolver._gn_analytic(s2, fib) @ p ** 2)
    mine2 = p * (eta @ p ** 2)
    a = p > 1e-6
    errs.append([np.abs(lin2db(full[a]) - lin2db(mine[a])).max(), np.abs(lin2db(full[a]) - lin2db(mine2[a])).max(), np.median(lin2db(full[a]) - lin2db(mine2[a]))])
print("NLI check dB (max GNPy vs eq, max GNPy vs stored eta, median):", np.round(errs, 4).tolist())
# SRS reference for the closed form used in the time loop: GNPy Raman solver at full load
SimParams.set_params({"raman_params": {"flag": True, "method": "perturbative", "order": 2, "result_spatial_resolution": 10e3, "solver_spatial_resolution": 100}, "nli_params": {"method": "gn_model_analytic"}})
pf = np.full(len(f), 10 ** (-1.3 / 10) * 1e-3)
s3 = create_arbitrary_spectral_information(frequency=f, pch=pf, baud_rate=B, slot_width=50e9, tx_osnr=40, tx_power=pf, roll_off=0.15)
srs3 = RamanSolver.calculate_stimulated_raman_scattering(s3, fib)
tilt = lin2db(srs3.power_profile[:, -1] / pf)
np.savez("sonuclar/gnpy_eta.npz", eta=eta, f=f, nfL=80, L_km=L_KM, srs_full_db=tilt)
print("SRS GNPy output minus input dB, first (L low), last (C high):", tilt[0], tilt[-1], "tilt", tilt[0] - tilt[-1])
try:
    import gnpy; print("gnpy", gnpy.__file__)
except Exception: pass
