"""Reduce the HHI Experimental Dataset 01 span spectra to channel powers without unpacking them to disk.

The 7z archive is streamed through the Windows tar (libarchive); each CSV starts with a header line, which marks the file
boundaries in the stream. For every file we integrate the OSA power spectral density over +-18 GHz around each of the 80 grid
frequencies and store the result per column (span 1 input, span 1/2/3 amplifier output, output of the line).
Output: sonuclar/hhi_span_powers.npz with ids (Data ID), cols, P (n, 5, 80) in dBm (relative to OSA resolution bandwidth).
"""
import sys, re, subprocess, io
import numpy as np

ARCH = sys.argv[1] if len(sys.argv) > 1 else r"data\hhi\experimental\sp\spans.7z"
TAR = r"C:\Windows\System32\tar.exe"
GRID = 192.1e12 + 50e9 * np.arange(80)
names = subprocess.run([TAR, "-tf", ARCH], capture_output=True, text=True).stdout.split()
ids = [int(re.match(r"ID_(\d+)_", n).group(1)) for n in names]
print(len(ids), "files", flush=True)
proc = subprocess.Popen([TAR, "-xOf", ARCH], stdout=subprocess.PIPE, bufsize=1 << 24)
out = np.full((len(ids), 5, 80), np.nan, np.float32)
COLS = ["Span 1 EDFA Input Power(dBm)", "Span 1 EDFA Output Power(dBm)", "Span 2 EDFA Output Power(dBm)",
        "Span 3 EDFA Output Power(dBm)", "Output OLS EDFA Output Power(dBm)"]
cols = COLS
buf, k, hdr = [], -1, []


def reduce(lines, k, hdr):
    try:
        a = np.loadtxt(io.StringIO("".join(lines)), delimiter=",", ndmin=2)
    except Exception as e:
        print("skip", k, e, flush=True); return
    f = a[:, 1]; o = np.argsort(f); f = f[o]; psd = 10 ** (a[o, 2:] / 10)
    lo = np.searchsorted(f, GRID - 18e9); hi = np.searchsorted(f, GRID + 18e9)
    cs = np.vstack([np.zeros((1, psd.shape[1])), np.cumsum(psd, 0)])
    p = 10 * np.log10(((cs[hi] - cs[lo]) / np.maximum(hi - lo, 1)[:, None]).T)
    for j, h in enumerate(hdr):
        if h in COLS:
            out[k, COLS.index(h)] = p[j]


for raw in io.TextIOWrapper(proc.stdout, encoding="utf8", errors="ignore"):
    if raw.startswith("Wavelength"):
        if buf:
            reduce(buf, k, hdr)
        hdr = raw.strip().split(",")[2:]
        k += 1; buf = []
        if k % 500 == 0:
            print(k, flush=True)
        continue
    buf.append(raw)
if buf:
    reduce(buf, k, hdr)
print("files parsed", k + 1, flush=True)
np.savez_compressed("sonuclar/hhi_span_powers.npz", ids=np.array(ids), cols=np.array(cols), P=out)
