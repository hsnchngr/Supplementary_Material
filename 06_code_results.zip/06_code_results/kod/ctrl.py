"""Controller bank shared by single stage and multi span runs, multi span C+L chain, and the QoT layer."""
import numpy as np
from scipy.special import erfc, erfcinv
import physics as ph
import sim
from sim import AGC, MPC, PumpActuator, Twin, steady_pump_nominal

H = 6.62607015e-34
SPAN_KM = 70.0
DELAY_SPAN = SPAN_KM * 4.9e-6
CR = 2.55e-17  # Raman gain slope, 1/(W m Hz), scaled so the closed form tilt matches the GNPy Raman solver at full C+L load
FMT = [("DP-QPSK", 100.0, 0.5, 1 / 2), ("DP-8QAM", 150.0, 0.58, 1 / 6), ("DP-16QAM", 200.0, 0.375, 1 / 10)]
BER_FEC = 2.0e-2
IMPL_DB = 1.5  # transceiver implementation penalty, applied on the GSNR


def q_db(gsnr_db, fmt=0):
    _, _, k1, k2 = FMT[fmt]
    snr = 10 ** ((gsnr_db - IMPL_DB) / 10)
    ber = np.clip(k1 * erfc(np.sqrt(k2 * snr)), 1e-300, 0.499)
    return 20 * np.log10(np.sqrt(2) * erfcinv(2 * ber))


Q_MIN = 20 * np.log10(np.sqrt(2) * erfcinv(2 * BER_FEC))


def required_gsnr(fmt):
    g = np.linspace(0, 30, 3001)
    return g[np.argmax(q_db(g, fmt) >= Q_MIN)]


REQ = [required_gsnr(i) for i in range(3)]


class BandCtl:
    """Per band controller bank for A stages. Every stage knows its event time and predicted input after the event."""

    def __init__(self, policy, p, u0, Pin0, gain0, survivors, P_after, t_event, delay, slew, lead, twin, mpc_kw=None,
                 agc_kw=None, noise_db=0.01, rng=None, tau_p=20e-6, dt=sim.DT):
        self.policy, self.p, self.dt = policy, p, dt
        self.A = p.A
        self.s = survivors.astype(float)
        self.sb = survivors.astype(bool)
        self.P_after, self.P0 = P_after, Pin0
        self.t_event, self.lead, self.delay = t_event, lead, delay
        self.rng = rng or np.random.default_rng(0)
        self.noise_db = noise_db
        self.act = PumpActuator(u0, delay, slew, tau_p, dt)
        kw_a = dict(agc_kw or {})
        if delay > 2e-4 and kw_a:  # the PI loop is detuned in proportion to the loop delay to stay stable
            kw_a = {k: v * 2e-4 / delay for k, v in kw_a.items()}
        self.agc = AGC(u0, **kw_a)
        self.post = 3e-3
        self.cmd = u0.copy()
        self.twin = twin
        self.nom = twin.m if twin else ph.ReservoirModel(p)
        self.g_tgt = (gain0 * self.s).sum(1) / np.maximum(self.s.sum(1), 1)
        self.pd_tgt = 10 * np.log10((Pin0 * 10 ** (gain0 / 10)).sum(1) / np.maximum(Pin0.sum(1), 1e-15))
        n_nom = self.nom.n_from_gain(gain0, np.ones_like(Pin0, bool))
        self.ff_ratio = steady_pump_nominal(self.nom, n_nom, P_after) / steady_pump_nominal(self.nom, n_nom, Pin0)
        self.ff_done = np.zeros(self.A, bool)
        self.ag_steps = max(1, int(round(self.agc.Ts / dt)))
        self.ctrl = None
        self.mp_steps = 20
        self.jit = 0.0
        self.g_off = np.zeros(self.A)
        self.solve_s = []
        if policy == "mpc":
            kw = dict(slew=slew, delay=delay, tau_p=tau_p, umax=2.0); kw.update(mpc_kw or {})
            self.jit = kw.pop("jitter_sig", 0.0)
            self.ctrl = MPC(twin, u0, **kw)
            self.ctrl.u_ref = u0 * self.ff_ratio
            self.ctrl.umin = 0.1 * u0
            self.mp_steps = int(round(self.ctrl.Ts / dt))
            nm = self.nom.n_from_gain(self.g_tgt[:, None], self.sb)
            self.ctrl.n_prev = nm.copy()
            self.ctrl.d = -twin.f(nm, u0, Pin0) if self.ctrl.adapt else np.zeros(self.A)

    def gain_of_n(self, nv):
        A = self.A
        nvv = nv.reshape(A, -1)
        ww = np.maximum(self.s.sum(1, keepdims=True), 1)
        e = (4.343 * self.nom.ea * self.s).sum(1, keepdims=True) / ww
        a = ((4.343 * self.nom.aa + self.nom.p.gff_db) * self.s).sum(1, keepdims=True) / ww
        g = e * nvv - a + self.g_off[:, None]
        if nv.size == A: return g[:, 0], e[:, 0]
        return g.ravel(), np.broadcast_to(e, nvv.shape).ravel()

    def tick(self, k, T, Pin, sol):
        if k % self.ag_steps == 0 and self.policy in ("agc", "ff", "mpc"):
            g_now = sol.gain_db(Pin)
            pd = 10 * np.log10((Pin * 10 ** (g_now / 10)).sum(1) / np.maximum(Pin.sum(1), 1e-15)) + self.noise_db * self.rng.standard_normal(self.A)
            e = self.pd_tgt - pd
            if self.policy in ("agc", "ff"):
                self.cmd = self.agc.update(e)
            if self.policy == "ff":
                fire = (T >= self.t_event - self.delay) & ~self.ff_done
                if fire.any():
                    self.agc.u = np.where(fire, self.agc.u * self.ff_ratio, self.agc.u); self.ff_done |= fire
                    self.cmd = self.agc.u.copy()
            if self.policy == "mpc":
                w = (T >= self.t_event - self.lead) & (T <= self.t_event + self.post)
                self.agc.u = np.where(w, self.cmd, self.agc.update(e))
                self.cmd = np.where(w, self.cmd, self.agc.u)
        if self.policy == "mpc" and k % self.mp_steps == 0:
            w = (T >= self.t_event - self.lead) & (T <= self.t_event + self.post)
            if w.any():
                c = self.ctrl
                ww = np.maximum(self.s.sum(1), 1)
                g_sv = (sol.gain_db(Pin) * self.s).sum(1) / ww + 0.03 * self.rng.standard_normal(self.A)
                n_m = self.nom.n_from_gain(g_sv[:, None], self.sb)
                if c.adapt:
                    pred = c.n_prev + c.Ts * (self.twin.f(c.n_prev, self.act.u, Pin) + c.d)
                    far = np.abs(T - self.t_event) > 1e-3
                    c.d = np.clip(c.d + np.where(far, 0.05, 0.0) * (n_m - pred) / c.Ts, -3e3, 3e3)
                c.n_prev = n_m.copy()
                self.g_off = g_sv - self.gain_of_n(n_m)[0] + self.g_off
                P_known = np.where((T >= self.t_event)[:, None], self.P_after, self.P0)
                new = c.solve(n_m, self.cmd, P_known, self.P_after, self.t_event - T, self.gain_of_n, self.g_tgt, self.sb, jitter=self.jit)
                self.cmd = np.where(w, new, self.cmd)
        return self.act.step(self.cmd)


def run_stage(p, u0, sol, Pin0, P_after, survivors, t_event, policy, T_end=0.02, delay=2e-4, slew=1000.0, tau_p=20e-6, lead=2e-3,
              jitter=None, twin=None, mpc_kw=None, agc_kw=None, rng=None, dt=sim.DT, record_every=4, P_pred=None):
    """Independent stages with their own event. jitter: actual minus notified event time."""
    A = p.A
    jitter = np.zeros(A) if jitter is None else jitter
    bank = BandCtl(policy, p, u0, Pin0, sol.gain_db(Pin0), survivors, P_after if P_pred is None else P_pred, t_event, delay, slew, lead, twin, mpc_kw, agc_kw, rng=rng, tau_p=tau_p, dt=dt)
    t_true = t_event + jitter
    s = survivors.astype(float)
    rg, ru, rt = [], [], []
    energy = np.zeros(A)
    u = u0.copy()
    for k in range(int(T_end / dt)):
        T = k * dt
        Pin = np.where((T >= t_true)[:, None], P_after, Pin0)
        u = bank.tick(k, T, Pin, sol) if policy != "none" else u
        sol.step(Pin, u, dt)
        energy += u * dt
        if k % record_every == 0:
            rg.append((sol.gain_db(Pin) * s).sum(1) / s.sum(1)); ru.append(np.array(u)); rt.append(T)
    return dict(t=np.array(rt), g=np.stack(rg, 1), u=np.stack(ru, 1), g_tgt=bank.g_tgt, energy=energy, t_event=t_true)


def load_twin(band, A, gff_mean, seeds=(0, 1, 2, 3, 4), kind="hybrid", path="sonuclar"):
    """kind: hybrid (physics plus ensemble residual) or phys (nominal reservoir only)."""
    p = ph.AmpParams(A, band, L=sim.DESIGN[band]["L"], K=sim.KB[band])
    p.gff_db = np.tile(gff_mean, (A, 1))
    nets = None
    if kind in ("hybrid", "node"):
        nets = []
        if kind == "node": seeds = (0, 1, 2)
        for s in seeds:
            d = np.load(f"{path}/{'twin' if kind == 'hybrid' else 'nodetwin'}_{band}_{s}.npz")
            v = [d[f"p{i}"] for i in range(len(d.files))]
            nets.append([(v[i], v[i + 1]) for i in range(0, len(v), 2)])
    return Twin(p, nets, use_phys=kind != "node")


class Chain:
    """Linear multi span C or C+L line. Fibre delay is an integer number of steps, so stages advance in parallel."""

    def __init__(self, nspans, bands=("C", "L"), seed=0, spread=1.0, dt=sim.DT * 2, alpha_err_db=0.0, pch_launch=None):
        self.N, self.bands, self.dt = nspans, bands, dt
        self.rng = np.random.default_rng(seed)
        self.pch = sim.PCH_IN_DBM + sim.TARGET_DB if pch_launch is None else pch_launch
        self.st = {}
        for b in bands:
            pp, u, sol, Pin = sim.make_stage(nspans, b, spread=spread, rng=self.rng)
            self.st[b] = dict(p=pp, u=u, sol=sol, K=pp.K)
        self.nu = np.concatenate([ph.grid(b, sim.KB[b]) for b in bands])
        self.idx = {}; i = 0
        for b in bands:
            self.idx[b] = (i, i + sim.KB[b]); i += sim.KB[b]
        self.d_steps = max(1, int(round(DELAY_SPAN / dt)))
        self.alpha_err = alpha_err_db + 0.15 * self.rng.standard_normal(nspans) * (spread > 0)  # span loss spread in dB
        self.launch = 10 ** (self.pch / 10) * 1e-3
        # commissioning at full load: each stage GFF restores a flat launch spectrum, SRS tilt included
        p_full = self.static(np.ones(len(self.nu), bool))
        for b in bands:
            i0, i1 = self.idx[b]
            st = self.st[b]
            Pin = p_full[:, i0:i1]
            ph.settle(st["sol"], Pin, st["u"], T=0.015)
            need = 10 * np.log10(self.launch / Pin)
            st["p"].gff_db = st["p"].gff_db + st["sol"].gain_db(Pin) - need
            st["need"] = need

    def fiber(self, P, s_idx):
        """P: (A,Ntot). Returns powers at the next stage input for the spans in s_idx."""
        nu = np.tile(self.nu, (P.shape[0], 1))
        Q = ph.srs_span(P, nu, alpha_db_km=0.2, L_km=SPAN_KM, cr=CR)
        return Q * 10 ** (-(1.5 + self.alpha_err[s_idx])[:, None] / 10)

    def static(self, mask_tot):
        """Static link map with ideal gain: what the controller may predict for each stage from the plan alone."""
        p = np.where(mask_tot, 10 ** (self.pch / 10) * 1e-3, 0.0)[None]
        inp = np.zeros((self.N, len(self.nu)))
        for s in range(self.N):
            inp[s] = self.fiber(p, np.array([s]))
        return inp


def run_chain(ch, mask_before, mask_after, policy, T0=4e-3, T_end=0.016, delay=2e-4, slew=1000.0, lead=2e-3, jitter_std=0.0, twins=None,
              mpc_kw=None, agc_kw=None, tau_p=20e-6, gff_cal=True, rec_dt=50e-6, eta=None, seed=1):
    """Propagate the event along the line under one control policy. Returns per span launch power, noise and pump traces."""
    N, dt = ch.N, ch.dt
    rng = np.random.default_rng(seed)
    Ntot = len(ch.nu)
    P_tx0 = np.where(mask_before, 10 ** (ch.pch / 10) * 1e-3, 0.0)
    P_tx1 = np.where(mask_after, 10 ** (ch.pch / 10) * 1e-3, 0.0)
    surv = mask_before & mask_after
    # initial steady state along the line with the installed pump and GFF
    p_in0 = ch.static(mask_before)
    p_in1 = ch.static(mask_after)
    bank = {}
    u_now = {}
    for b in ch.bands:
        i0, i1 = ch.idx[b]
        st = ch.st[b]
        sol = ph.ZSolver(st["p"])
        sol.n = st["sol"].n.copy()
        Pin = p_in0[:, i0:i1]
        u_b = st["u"].copy()
        mk = np.tile(mask_before[i0:i1], (N, 1)).astype(float)
        tgt = (st["need"] * mk).sum(1) / np.maximum(mk.sum(1), 1)
        for it in range(30):  # the AGC has converged on the pre event load before the run starts
            ph.settle(sol, Pin, u_b, T=0.0006, dt=20e-6)
            u_b = np.clip(u_b * (1 + 0.12 * (tgt - (sol.gain_db(Pin) * mk).sum(1) / np.maximum(mk.sum(1), 1))), 1e-3, 2.0)
        ph.settle(sol, Pin, u_b, T=0.004, dt=20e-6)
        st["run"] = sol
        st["u0_run"] = u_b
        t_ev = T0 + DELAY_SPAN * (np.arange(N) + 1)
        tw = twins[b] if twins else None
        sv = np.tile(surv[i0:i1], (N, 1))
        if sv.sum() == 0: sv[:] = True
        bank[b] = BandCtl(policy, st["p"], u_b, Pin, sol.gain_db(Pin), sv, p_in1[:, i0:i1], t_ev, delay, slew, lead, tw, mpc_kw, agc_kw, rng=rng, tau_p=tau_p, dt=dt)
        u_now[b] = u_b.copy()
    # delay line of stage outputs
    D = ch.d_steps
    buf = np.zeros((D, N + 1, Ntot))
    out0 = np.zeros((N + 1, Ntot))
    out0[0] = P_tx0
    for b in ch.bands:
        i0, i1 = ch.idx[b]
        Pin = p_in0[:, i0:i1]
        out0[1:, i0:i1] = Pin * 10 ** (ch.st[b]["run"].gain_db(Pin) / 10)
    buf[:] = out0
    every = int(round(rec_dt / dt))
    t_jit = rng.normal(0, jitter_std) if jitter_std > 0 else 0.0
    rec = dict(t=[], launch=[], noise=[], u={b: [] for b in ch.bands})
    energy = 0.0
    nf_fac = {b: None for b in ch.bands}
    for k in range(int(T_end / dt)):
        T = k * dt
        j = k % D
        delayed = buf[j].copy()  # outputs one fibre delay ago
        inp = ch.fiber(delayed[:N], np.arange(N))
        tx = P_tx1 if T >= T0 + t_jit else P_tx0
        new_out = np.zeros_like(delayed)
        new_out[0] = tx
        noise = np.zeros((N, Ntot))
        for b in ch.bands:
            i0, i1 = ch.idx[b]
            st = ch.st[b]
            Pin = inp[:, i0:i1]
            u = bank[b].tick(k, T, Pin, st["run"]) if policy != "none" else u_now[b]
            st["run"].step(Pin, u, dt)
            g = st["run"].gain_db(Pin)
            new_out[1:, i0:i1] = Pin * 10 ** (g / 10)
            energy += u.sum() * dt
            if k % every == 0:
                nf = st["run"].nf_db()
                noise[:, i0:i1] = H * st["p"].nu * 32e9 * 10 ** ((nf + g) / 10)
                rec["u"][b].append(u.copy())
        buf[j] = new_out
        if k % every == 0:
            rec["t"].append(T); rec["launch"].append(new_out.astype(np.float32)); rec["noise"].append(noise.astype(np.float32))
    return dict(t=np.array(rec["t"]), launch=np.stack(rec["launch"]), noise=np.stack(rec["noise"]), u={b: np.stack(v) for b, v in rec["u"].items()},
                energy=energy, surv=surv, T0=T0, idx=ch.idx, rec_dt=rec_dt)


def gsnr_trace(res, eta, tx_osnr_db=40.0):
    """End to end GSNR of each channel per time, following the wavefront: span s is read one fibre delay later than span s-1."""
    L, Nz = res["launch"], res["noise"]
    nt, Nsp1, K = L.shape
    N = Nsp1 - 1
    shift = int(round(DELAY_SPAN / res["rec_dt"]))
    inv = np.full((nt, K), 10 ** (-tx_osnr_db / 10))
    for s in range(N + 1):
        idx = np.minimum(np.arange(nt) + s * shift, nt - 1)
        P = L[idx, s]
        if s < N:
            nli = P * ((P ** 2) @ eta.T)
            inv += nli / np.maximum(P, 1e-15)
        if s > 0:
            a = Nz[idx, s - 1]
            inv += a / np.maximum(P, 1e-15)
    return -10 * np.log10(inv)


def assign_formats(g0_db, margin_db):
    """Highest order format that clears the threshold after reserving the margin."""
    r = np.zeros_like(g0_db); f = np.full(g0_db.shape, -1)
    for i in range(3):
        ok = g0_db - margin_db >= REQ[i]
        r[ok] = FMT[i][1]; f[ok] = i
    return r, f


def capacity_trace(g_db, fmt):
    """Instantaneous C_net(T) in Tb/s and per channel Q margin to the threshold under the assigned format."""
    nt, K = g_db.shape
    q = np.full((nt, K), np.nan)
    for i in range(3):
        m = fmt == i
        if m.any(): q[:, m] = q_db(g_db[:, m], i)
    ok = np.nan_to_num(q, nan=-99) >= Q_MIN
    rate = np.array([FMT[f][1] if f >= 0 else 0.0 for f in fmt])
    return (ok * rate).sum(1) * 1e-3, q
