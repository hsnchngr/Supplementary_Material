"""Download the COSMOS EDFA measurement JSON files (booster, preamp, multispan, remeasurement)."""
import json, os, urllib.request, urllib.parse
from concurrent.futures import ThreadPoolExecutor
BASE = "https://raw.githubusercontent.com/functions-lab/COSMOS-EDFA-Dataset/main/"
tree = json.load(open("data/tree.json", encoding="utf8"))["tree"]
want = [t for t in tree if t["type"] == "blob" and t["path"].endswith(".json")
        and t["path"].startswith(("dataset/", "misc/remeasurement/", "misc/measurement_config/", "misc/live_comp_data_new/"))]
def get(t):
    out = os.path.join("data", "cosmos", t["path"])
    if os.path.exists(out) and os.path.getsize(out) == t["size"]:
        return 0
    os.makedirs(os.path.dirname(out), exist_ok=True)
    urllib.request.urlretrieve(BASE + urllib.parse.quote(t["path"]), out + ".part")
    os.replace(out + ".part", out)
    return 1
with ThreadPoolExecutor(8) as ex:
    n = sum(ex.map(get, want))
print("files", len(want), "new", n)
