"""Tier 3: multi span C+L events, transient GSNR and Q from the GNPy GN matrix, margin allocation and capacity, Pareto sweep."""
import os, sys, json, time
os.environ.setdefault("OMP_NUM_THREADS", "1"); os.environ.setdefault("MKL_NUM_THREADS", "1")
sys.path.insert(0, "kod")
import numpy as np
import physics as ph, sim, ctrl
from multiprocessing import get_context
ETA = None


def run(c):
    global ETA
    if ETA is None: ETA = np.load("sonuclar/gnpy_eta.npz")["eta"]
    # eta ordering in the file is L then C; the chain keeps C then L
    nL = 80
    perm = np.concatenate([np.arange(nL, 175), np.arange(nL)])
    eta = ETA[np.ix_(perm, perm)]
    agc = json.load(open("sonuclar/agc_tune.json"))["agc"]
    ch = ctrl.Chain(c["spans"], seed=c["seed"], spread=c.get("spread", 1.0), alpha_err_db=c.get("alpha_err", 0.0), pch_launch=c.get("pch"))
    rng = np.random.default_rng(1000 + c["seed"])
    K = len(ch.nu)
    i0, i1 = ch.idx["C"]; l0, l1 = ch.idx["L"]
    m0 = np.zeros(K, bool)
    load = c.get("load", 1.0)
    m0[rng.permutation(np.arange(i0, i1))[: int(round(95 * load))]] = True
    m0[rng.permutation(np.arange(l0, l1))[: int(round(80 * load))]] = True
    m1 = m0.copy()
    for b, frac in (("C", c.get("drop_c", 0.5)), ("L", c.get("drop_l", 0.0))):
        a, z = ch.idx[b]
        act = np.where(m0[a:z])[0] + a
        m1[rng.permutation(act)[: int(round(len(act) * frac))]] = False
    twins = None
    if c["policy"] == "mpc":
        twins = {b: ctrl.load_twin(b, c["spans"], np.load(f"data/trans_{b}_train.npz")["gff"], kind=c.get("twin", "hybrid")) for b in ("C", "L")}
        # the nominal twin takes the commissioned GFF of each stage
        for b in ("C", "L"):
            twins[b].p.gff_db = ch.st[b]["p"].gff_db.copy()
    t0 = time.time()
    T0 = 6e-3
    T_end = T0 + c["spans"] * ctrl.DELAY_SPAN + 9e-3
    r = ctrl.run_chain(ch, m0, m1, c["policy"], T0=T0, T_end=T_end, delay=c.get("delay", 2e-4), slew=c.get("slew", 1000.0), lead=c.get("lead", 2e-3),
                       jitter_std=c.get("jitter", 0.0), twins=twins, mpc_kw=c.get("mpc_kw"), agc_kw=agc, seed=c["seed"] + 77)
    G = ctrl.gsnr_trace(r, eta)
    t = r["t"]; sv = r["surv"]
    shift = int(round(ctrl.DELAY_SPAN / r["rec_dt"]))
    # reference before any planner can act (the longest lead is 5 ms), then a window that follows the wavefront
    t_a = np.searchsorted(t, 0.9e-3); t_b = len(t) - c["spans"] * shift - 1
    g0 = G[max(t_a - 6, 0):t_a].mean(0)
    Gw = G[t_a:t_b]
    gmin = Gw.min(0)
    pen = g0 - gmin
    # launch excursion of survivors along the line relative to the pre event value
    L = r["launch"]
    pre = L[max(t_a - 6, 0):t_a].mean(0)
    W = t_b - t_a
    ex = np.stack([L[t_a + s * shift:t_a + s * shift + W, s, :] for s in range(1, c["spans"] + 1)], 1)
    with np.errstate(divide="ignore", invalid="ignore"):
        ex = 10 * np.log10(ex / pre[None, 1:])
    ex_sv = ex[:, :, sv]
    span_peak = np.nanmax(np.abs(ex_sv), axis=(0, 2))
    span_max_pos = np.nanmax(ex_sv, axis=(0, 2))
    span_min_neg = np.nanmin(ex_sv, axis=(0, 2))
    out = dict(c)
    out.pop("mpc_kw", None)
    name_kw = c.get("mpc_kw") or {}
    out.update(kappa=name_kw.get("kappa", 0.0), wall=time.time() - t0, energy=float(r["energy"]), span_peak=span_peak.tolist(), span_pos=span_max_pos.tolist(), span_neg=span_min_neg.tolist(),
               g0=g0[sv].tolist(), pen=pen[sv].tolist(), band=np.array(["C" if i < 95 else "L" for i in np.where(sv)[0]]).tolist(), n_surv=int(sv.sum()), n_loaded=int(m0.sum()))
    # traces for figures on one representative case
    if c.get("save"):
        cs = np.where(sv)[0]
        np.savez(f"sonuclar/net_trace_{c['save']}_{c['name']}.npz", t=t[t_a:t_b], G=Gw[:, cs].astype(np.float32), g0=g0[cs], chan=cs, ex=ex_sv.astype(np.float32)[::2], u_C=r["u"]["C"][::2].astype(np.float32))
    return out


POL = [("AGC", "agc", None), ("FF", "ff", None), ("MPC", "mpc", dict()), ("UA-MPC", "mpc", dict(kappa=2.0, jitter_sig=5e-5))]

if __name__ == "__main__" and len(sys.argv) > 2 and sys.argv[2] == "traces":
    jobs = [dict(group="trace", name=nm, policy=pol, spans=20, seed=0, drop_c=d, mpc_kw=mk, jitter=5e-5, save=f"20_{int(d*100)}") for d in (0.5, 0.8) for nm, pol, mk in POL]
    with get_context("spawn").Pool(8) as pool: pool.map(run, jobs)
    sys.exit()
if __name__ == "__main__":
    jobs = []
    def J(group, spans, seed, drop_c=0.5, pols=POL, **kw):
        for nm, pol, mk in pols:
            jobs.append(dict(group=group, name=nm, policy=pol, spans=spans, seed=seed, drop_c=drop_c, mpc_kw=mk, **kw))
    SEEDS = list(range(8))
    for spans in (5, 10, 20, 30):
        for drop in (0.2, 0.5, 0.8):
            for s in SEEDS:
                J("main", spans, s, drop, jitter=5e-5, save=f"{spans}_{int(drop*100)}" if (s == 0 and spans == 20) else None)
    for load in (0.5, 0.75):
        for s in SEEDS: J("load", 20, s, 0.5, load=load, jitter=5e-5)
    for s in SEEDS: J("cl_drop", 20, s, 0.5, drop_l=0.5, jitter=5e-5)
    for s in SEEDS: J("ldrop", 20, s, 0.0, drop_l=0.8, jitter=5e-5)
    for s in SEEDS: J("alpha", 20, s, 0.5, alpha_err=0.5, jitter=5e-5)
    for s in SEEDS[:4]:
        for jit in (0.0, 2e-4, 5e-4): J("jit", 20, s, 0.5, jitter=jit)
    for s in SEEDS[:4]:
        for delay in (1e-4, 5e-4, 1e-3, 2e-3): J("delay", 20, s, 0.5, delay=delay, jitter=5e-5)
        for lead in (0.0, 5e-4, 1e-3, 5e-3): J("lead", 20, s, 0.5, lead=lead, pols=[POL[2]], jitter=5e-5)
    # Pareto sweep on 20 spans: launch power and controller weights
    for s in SEEDS[:4]:
        for pch in (-3.0, -2.2, -1.3, -0.5, 0.3):
            J("pareto", 20, s, 0.5, pch=pch, jitter=5e-5)
        for wu in (1e-3, 1e-2, 5e-2, 2e-1):
            for kap in (0.0, 2.0):
                jobs.append(dict(group="pareto_w", name=f"w{wu}_k{kap}", policy="mpc", spans=20, seed=s, drop_c=0.5, jitter=5e-5, mpc_kw=dict(w_u=wu, kappa=kap, jitter_sig=5e-5)))
    print(len(jobs), flush=True)
    t0 = time.time()
    with get_context("spawn").Pool(int(sys.argv[1]) if len(sys.argv) > 1 else 22) as pool:
        res = []
        for i, r in enumerate(pool.imap_unordered(run, jobs)):
            res.append(r)
            if i % 40 == 0:
                print(i, int(time.time() - t0), r["group"], r["name"], r["spans"], round(r["wall"], 1), "pen95", round(float(np.percentile(r["pen"], 95)), 2), flush=True)
                json.dump(res, open("sonuclar/network_partial.json", "w"))
    json.dump(res, open("sonuclar/network.json", "w"))
