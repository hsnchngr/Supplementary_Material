"""Parse COSMOS EDFA JSON into compact npz arrays. Only active channels carry a valid gain."""
import json, glob, re, os, hashlib, sys
import numpy as np
from multiprocessing import Pool
ROOT = "data/cosmos"
PAT = re.compile(r"edfa_meas_(rdm\d-\w+?)\.bed_(booster|preamp)")
def spec(d):
    return np.array([d[str(i)] for i in range(1, 96)], np.float32)
def parse(f):
    t = PAT.search(os.path.basename(f))
    if t is None: return None
    dev, typ = t.groups()
    try: D = json.load(open(f))["measurement_data"]
    except Exception as e:
        print("skip", f, e); return None
    rows = []
    for m in D:
        try:
            if typ == "preamp":
                info, act = m["roadm_dut_preamp_info"], m["roadm_flatten_wss_active_channel_index"]
                pi, po = spec(m["roadm_dut_preamp_input_power_spectra"]), spec(m["roadm_dut_wss_input_power_spectra"])
            else:
                info, act = m["roadm_dut_edfa_info"], m["roadm_dut_wss_active_channel_index"]
                pi, po = spec(m["roadm_dut_wss_output_power_spectra"]), spec(m["roadm_dut_booster_output"])
        except KeyError:
            continue
        mask = np.zeros(95, bool); mask[np.array(act) - 1] = True
        rows.append((pi, po, mask, info["target_gain"], info["input_power"], info["output_power"],
                     m.get("repeat_index", 0), int(hashlib.md5(mask.tobytes()).hexdigest()[:8], 16)))
    if not rows: return None
    a = list(zip(*rows))
    return dict(pin=np.stack(a[0]), pout=np.stack(a[1]), mask=np.stack(a[2]), gt=np.array(a[3], np.float32),
                ptin=np.array(a[4], np.float32), ptout=np.array(a[5], np.float32), rep=np.array(a[6]),
                cfg=np.array(a[7], np.int64), dev=np.array([dev] * len(rows)), typ=np.array([typ] * len(rows)),
                src=np.array([f.split("cosmos")[1].split(os.sep)[1] if False else os.path.dirname(f).replace(ROOT, "")[:40]] * len(rows)))
def run(pattern, out):
    fs = sorted(f for f in glob.glob(os.path.join(ROOT, pattern), recursive=True))
    with Pool(12) as p: res = [r for r in p.map(parse, fs) if r]
    A = {k: np.concatenate([r[k] for r in res]) for k in res[0]}
    np.savez_compressed(out, **A); print(out, len(fs), A["pin"].shape, np.unique(A["dev"]))
if __name__ == "__main__":
    run("dataset/booster/**/*.json", "data/parsed_booster.npz")
    run("dataset/preamp/**/*.json", "data/parsed_preamp.npz")
    run("misc/remeasurement/**/*.json", "data/parsed_remeas.npz")
    run("misc/live_comp_data_new/*.json", "data/parsed_live2026.npz")
