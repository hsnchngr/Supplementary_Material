"""Measured QoT check on the Fraunhofer HHI Experimental Dataset 01 (Santos et al., JOCN 2024).

Physics core: back-to-back transceiver SNR + per span ASE (characterized noise figure, measured amplifier
input power) + GN model NLI (closed form of GNPy, eq. 120 of arXiv:1209.0394) for the measured channel allocation.
Then few-shot offset calibration and split conformal margins, tested on held out load configurations.
Second variant: channel powers of the CUT at every span launch from the span spectra (kod/12_hhi_spectra.py), either measured
for each sample or predicted by a per channel tilt model fitted on the spectra of the K calibration configurations.
Output: sonuclar/hhi_qot.json
"""
import json, hashlib, sys
import numpy as np, pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor

EX = "data/hhi/experimental/ex/"
d = pd.read_csv(EX + "dataset.csv")
edfa = pd.read_csv(EX + "edfaCharacterization.csv")
fib = pd.read_csv(EX + "fibersCharacterization.csv")
fib.columns = [c.strip() for c in fib.columns]

H, C0 = 6.62607015e-34, 299792458.0
N2, AEFF = 2.6e-20, 80e-12
GRID = 192.1e12 + 50e9 * np.arange(80)
PCH = 10 ** (-2 / 10) * 1e-3                     # documented launch power per channel, W
SPANS = [("75", "76", "EDFA70"), ("77", "78", "EDFA150"), ("73", "79", "EDFA160")]


def spool(sp, col, f):
    ff = fib["Frequency(THz)"].values * 1e12
    o = np.argsort(ff)
    return np.interp(f, ff[o], fib[f"Spool{sp} - {col}"].values[o])


def eta_span(s1, s2, rs):
    """GN eta matrix (1/W^2) for one 80 km span made of two 40 km spools, cut x pump, pumps of bandwidth rs."""
    f = GRID
    eta = np.zeros((80, 80))
    for k, sp in enumerate((s1, s2)):
        a_db = spool(sp, "Attenuation(dB/km)", f)
        D = spool(sp, "Dispersion(ps/nm/km)", f) * 1e-6        # s/m^2
        alpha = a_db / 10 * np.log(10) / 1e3                   # 1/m
        beta2 = -D * (C0 / f) ** 2 / (2 * np.pi * C0)
        gamma = 2 * np.pi * N2 * f / (C0 * AEFF)
        L = 40e3
        leff = (1 - np.exp(-alpha * L)) / alpha
        la = 1 / alpha
        df = f[None, :] - f[:, None]
        b2 = np.abs((beta2[:, None] + beta2[None, :]) / 2)
        psi = (np.arcsinh(np.pi ** 2 * la[:, None] * b2 * rs * (df + rs / 2))
               - np.arcsinh(np.pi ** 2 * la[:, None] * b2 * rs * (df - rs / 2))) / 2
        psi *= leff[:, None] ** 2 / (2 * np.pi * b2 * la[:, None])
        w = np.full((80, 80), 2 * 16 / 27); np.fill_diagonal(w, 16 / 27)
        e = gamma[:, None] ** 2 * w * psi / rs ** 2
        if k == 1:   # second spool sees the power left after the first spool (incoherent, no amplifier between)
            att = 10 ** (-spool(s1, "Attenuation(dB/km)", f) * 40 / 10)
            e = e * att[None, :] ** 2   # NLI relative to the attenuated CUT scales with the attenuated pump power squared
        eta += e
    return eta


A = np.stack(d["Channel Allocation Vector"].astype(str).map(lambda s: np.array([int(c) for c in s])).values).astype(float)

# index 0 of the vector is CUT #1 = 192.1 THz (checked: the CUT bit is always set)
cut = np.round((d["CUT (THz)"].values * 1e12 - GRID[0]) / 50e9).astype(int)
assert (A[np.arange(len(d)), cut] == 1).all()
rs = d["Symbol Rate (GB)"].values * 1e9
dist = d["Distance(km)"].values
nsp = dist // 80
fcut = GRID[cut]
nch = A.sum(1)

# line noise per span (linear 1/SNR)
inv_ase = np.zeros(len(d)); inv_nli = np.zeros(len(d))
ef = edfa["Frequency (THz)"].values * 1e12; o = np.argsort(ef)
for k, (s1, s2, amp) in enumerate(SPANS):
    on = nsp > k
    nf = 10 ** (np.interp(fcut, ef[o], edfa[f"{amp} Noise Figure (dB)"].values[o]) / 10)
    pin = 10 ** (d[f"Instr:{amp} inPower (dBm)"].values / 10) * 1e-3 / nch
    inv_ase += on * nf * H * fcut * rs / pin
    for r in (28e9, 32e9):
        m = on & (rs == r)
        if m.any():
            E = eta_span(s1, s2, r)
            inv_nli[m] += (E[cut[m]] * A[m]).sum(1) * PCH ** 2

snr = d["SNR (dB)"].values
fmt = (d["Modulation Order"].astype(str) + "_" + d["Symbol Rate (GB)"].astype(str)).values
conf = (d["Channel Allocation Vector"].astype(str) + "_" + d["CUT #"].astype(str)).values
uconf = np.unique(conf)
h = np.array([int(hashlib.md5(c.encode()).hexdigest()[:8], 16) / 2 ** 32 for c in uconf])
test_conf = set(uconf[h < 0.5])
is_test = np.array([c in test_conf for c in conf])
pool_conf = uconf[h >= 0.5]


def terminal_fit(mask, load=True):
    """Back-to-back commissioning: 1/SNR_trx = a(format, CUT) + kappa(format) * n_ch.
    The kappa term is the noise of a terminal amplifier held at constant total output power: its ASE stays fixed
    while the power per channel falls with the channel count, so 1/SNR grows linearly with n_ch."""
    par = {}
    b = mask & (dist == 0)
    for f_ in np.unique(fmt):
        m = b & (fmt == f_)
        cuts = np.unique(cut[m])
        X = np.column_stack([(cut[m][:, None] == cuts[None, :]).astype(float)] + ([nch[m]] if load else []))
        y = 10 ** (-snr[m] / 10)
        co, *_ = np.linalg.lstsq(X, y, rcond=None)
        par[f_] = (dict(zip(cuts, co[:len(cuts)])), co[-1] if load else 0.0)
    return par


def phys_pred(rows, par, ia=None):
    ia = inv_ase if ia is None else ia
    inv_trx = np.array([par[fmt[i]][0][cut[i]] + par[fmt[i]][1] * nch[i] for i in rows])
    return 10 * np.log10(1 / (inv_trx + ia[rows] + inv_nli[rows]))


def offsets(rows_c, res_c, rows_t, lam=4.0):
    """per channel offset for each distance, shrunk to the mean offset of that distance, as in the amplifier twin"""
    out_ = np.full(len(rows_t), res_c.mean())
    for dd in (80, 160, 240):
        md = dist[rows_c] == dd
        g = res_c[md].mean() if md.any() else res_c.mean()
        out_[dist[rows_t] == dd] = g
        for c_ in np.unique(cut):
            mc = md & (cut[rows_c] == c_); mt = (dist[rows_t] == dd) & (cut[rows_t] == c_)
            n = mc.sum(); w = n / (n + lam)
            out_[mt] = w * (res_c[mc].mean() if n else 0) + (1 - w) * g
    return out_


# ---------------- channel power tilt from the span spectra (kod/12_hhi_spectra.py) ----------------
Z = np.load("sonuclar/hhi_span_powers.npz")
zrow = {i: k for k, i in enumerate(Z["ids"])}
PZ = Z["P"][np.array([zrow[i] for i in d["Data ID"]])]          # (n, 5, 80) channel powers, dBm per OSA bin
Ab = A.astype(bool)
MEANACT = 10 * np.log10(np.stack([(10 ** (PZ[:, c] / 10) * Ab).sum(1) / Ab.sum(1) for c in range(5)], 1))
DEV = PZ - MEANACT[:, :, None]                                   # power of each channel relative to the mean active channel
DEVCUT = DEV[np.arange(len(d)), :, cut]                         # (n, 5) for the channel under test
U = 10 * np.log10(nch / 80)


EO = np.argsort(ef)


def ase_with(dev3):
    """ASE of each span with the power of the CUT at the amplifier input shifted by its relative launch power"""
    ia = np.zeros(len(d))
    for k, (s1, s2, amp) in enumerate(SPANS):
        on = nsp > k
        nf = 10 ** (np.interp(fcut, ef[EO], edfa[f"{amp} Noise Figure (dB)"].values[EO]) / 10)
        pin = 10 ** (d[f"Instr:{amp} inPower (dBm)"].values / 10) * 1e-3 / nch * 10 ** (np.nan_to_num(dev3[:, k]) / 10)
        ia += on * nf * H * fcut * rs / pin
    return ia


def fit_tilt(rows):
    """per channel tilt model a(c, ch) + D(c, ch) u for the launch of span c, u = 10 log10(n_ch / 80), from full spectra"""
    par = np.zeros((3, 80, 2))
    for c in range(3):
        for ch in range(80):
            m = Ab[rows, ch] & ~np.isnan(DEV[rows, c + 1, ch])
            y = DEV[rows][m, c + 1, ch]
            if m.sum() < 2:
                par[c, ch] = [y.mean() if m.any() else 0.0, 0.0]; continue
            Xt = np.column_stack([np.ones(m.sum()), U[rows][m]])
            par[c, ch] = np.linalg.solve(Xt.T @ Xt + np.diag([1e-6, 0.5]), Xt.T @ y)
    return np.stack([par[c, cut, 0] + par[c, cut, 1] * U for c in range(3)], 1)


inv_ase_tel = ase_with(DEVCUT[:, 1:4])


def conformal(calc, cr, rc, e1):
    """jackknife residuals (offset of each calibration configuration fitted without it), 95/99% margins and outage"""
    sc = []
    for c in calc:
        mi = conf[cr] == c
        if mi.sum() == 0 or mi.all(): continue
        sc.append(rc[mi] - offsets(cr[~mi], rc[~mi], cr[mi]))
    sc = np.sort(np.concatenate(sc)); n = len(sc)
    cv = {"n_cal_rows": int(n)}
    for a in (0.05, 0.01):
        marg = -sc[max(int(np.floor(a * (n + 1))) - 1, 0)]
        cv[str(1 - a)] = {"margin_db": float(marg), "outage": float(np.mean(e1 < -marg))}
    cv["no_margin_outage"] = float(np.mean(e1 < 0))
    cv["fixed_1db_outage"] = float(np.mean(e1 < -1.0))
    return cv


line = dist > 0
pool = ~is_test
out = {}
rng = np.random.default_rng(0)
te = np.where(is_test & line)[0]
term0 = terminal_fit(pool, load=False)
term = terminal_fit(pool, load=True)
out["kappa_db_40ch"] = {f_: float(10 * np.log10(1 + term[f_][1] * 40 / np.mean(list(term[f_][0].values())))) for f_ in term}
for name, par, ia in (("zero_shot_noload", term0, inv_ase), ("zero_shot", term, inv_ase), ("zero_shot_tel", term, inv_ase_tel)):
    p = phys_pred(te, par, ia); r = snr[te] - p
    o = {"mae": float(np.mean(np.abs(r))), "bias": float(np.mean(r)), "rmse": float(np.sqrt(np.mean(r ** 2)))}
    o["by_dist"] = {int(dd): {"mae": float(np.mean(np.abs(r[dist[te] == dd]))), "bias": float(np.mean(r[dist[te] == dd]))} for dd in (80, 160, 240)}
    m240 = dist[te] == 240
    o["load_slope_40ch"] = float(np.polyfit(nch[te][m240], p[m240], 1)[0] * 40)
    out[name] = o
p_te = phys_pred(te, term); r0 = snr[te] - p_te
p_te_tel = phys_pred(te, term, inv_ase_tel)
m240 = dist[te] == 240
out["meas"] = {"load_slope_40ch": float(np.polyfit(nch[te][m240], snr[te][m240], 1)[0] * 40),
               "ase_snr_240_db": float(10 * np.log10(np.mean(1 / inv_ase[te][m240]))),
               "nli_snr_240_db": float(10 * np.log10(np.mean(1 / inv_nli[te][m240]))),
               "n_test_rows": int(len(te)), "n_conf_test": int(len(test_conf)), "n_conf_pool": int(len(pool_conf)),
               "b2b_snr_range": [float(snr[dist == 0].min()), float(snr[dist == 0].max())]}
# tilt of the edge channels against load, per measured column (span 1 input, launch of spans 1 to 3, line output)
cols = ["span1_in", "launch1", "launch2", "launch3", "line_out"]
tilt = {}
for c in range(5):
    tilt[cols[c]] = {}
    for q in (0, 40, 79):
        m = (cut == q) & ~np.isnan(DEVCUT[:, c])
        tilt[cols[c]][int(q)] = float(np.polyfit(nch[m], DEVCUT[m, c], 1)[0] * 40)
out["tilt_db_per_40ch"] = tilt
# curves for the figure: mean relative CUT power per channel count bin, edge channels, each column
bins = [(40, 47), (48, 55), (56, 63), (64, 71), (72, 80)]
out["tilt_curves"] = {cols[c]: {int(q): [[float(np.mean([lo, hi])), float(np.nanmean(DEVCUT[(cut == q) & (nch >= lo) & (nch <= hi), c]))] for lo, hi in bins]
                                for q in (0, 79)} for c in range(5)}
print(json.dumps({k: out[k] for k in ("kappa_db_40ch", "zero_shot_noload", "zero_shot", "zero_shot_tel", "meas", "tilt_db_per_40ch")}, indent=1))

# data driven baseline: features of the unified HHI QoT study plus load (channel count and occupancy of 8 sub-bands)
X = np.column_stack([rs / 1e9, d["Modulation Order"].values, fcut / 1e12, dist, nch, A.reshape(len(d), 8, 10).sum(2)])
b2b_pool = np.where(pool & (dist == 0))[0]
KS = [1, 2, 5, 10, 20, 50, 100, len(pool_conf)]
res = {k: {"phys_cal": [], "phys_tel": [], "phys_tilt": [], "tilt_err": [], "gb": [], "hyb": []} for k in KS}
cov, cov_tel = {}, {}
for K in KS:
    for rep in range(10 if K < len(pool_conf) else 1):
        calc = rng.choice(pool_conf, K, replace=False); cal = set(calc)
        cm = np.array([c in cal for c in conf])
        cr = np.where(cm & line)[0]
        pc = phys_pred(cr, term); rc = snr[cr] - pc
        e1 = snr[te] - (p_te + offsets(cr, rc, te))
        res[K]["phys_cal"].append(float(np.mean(np.abs(e1))))
        # measured channel powers of every sample (OCM telemetry)
        rct = snr[cr] - phys_pred(cr, term, inv_ase_tel)
        e2 = snr[te] - (p_te_tel + offsets(cr, rct, te))
        res[K]["phys_tel"].append(float(np.mean(np.abs(e2))))
        # tilt predicted from the full spectra of the K calibration configurations only
        dv = fit_tilt(np.where(cm & (dist == 240))[0])
        ia = ase_with(dv)
        rcm = snr[cr] - phys_pred(cr, term, ia)
        e3 = snr[te] - (phys_pred(te, term, ia) + offsets(cr, rcm, te))
        res[K]["phys_tilt"].append(float(np.mean(np.abs(e3))))
        res[K]["tilt_err"].append(float(np.nanmean(np.abs(dv[te] - DEVCUT[te, 1:4]))))
        tr = np.concatenate([b2b_pool, cr])
        gb = HistGradientBoostingRegressor(max_iter=300, learning_rate=0.05, random_state=rep).fit(X[tr], snr[tr])
        res[K]["gb"].append(float(np.mean(np.abs(snr[te] - gb.predict(X[te])))))
        if len(cr) >= 24:
            hy = HistGradientBoostingRegressor(max_iter=200, learning_rate=0.05, max_depth=3, random_state=rep).fit(X[cr], rc - offsets(cr, rc, cr))
            res[K]["hyb"].append(float(np.mean(np.abs(e1 - hy.predict(X[te])))))
        if K in (10, 20, 50, len(pool_conf)):
            cv = conformal(calc, cr, rc, e1); cv["zero_shot_no_margin_outage"] = float(np.mean(r0 < 0))
            cov.setdefault(K, []).append(cv)
            cov_tel.setdefault(K, []).append(conformal(calc, cr, rct, e2))
summary = {str(k): {m: (float(np.mean(v)) if v else None) for m, v in res[k].items()} for k in KS}
out["few_shot"] = summary


def avg(xs):
    if isinstance(xs[0], dict): return {k: avg([x[k] for x in xs]) for k in xs[0]}
    return float(np.mean(xs))


out["conformal"] = {str(k): {**avg(v), "draws": len(v), "worst_outage_0.99": float(max(x["0.99"]["outage"] for x in v))} for k, v in cov.items()}
out["conformal_tel"] = {str(k): {**avg(v), "draws": len(v), "worst_outage_0.99": float(max(x["0.99"]["outage"] for x in v))} for k, v in cov_tel.items()}
print(json.dumps(summary, indent=1)); print(json.dumps(out["conformal"], indent=1)); print(json.dumps(out["conformal_tel"], indent=1))
json.dump(out, open("sonuclar/hhi_qot.json", "w"), indent=1)
