"""Closed loop simulation: plant wrapper, twin (physics + residual network), AGC, feedforward and MPC controllers."""
import numpy as np
import physics as ph

DT = 5e-6
TARGET_DB = 15.5
PCH_IN_DBM = -16.8  # per channel at the stage input at full load
DESIGN = {"C": dict(L=18.0, nd=0.62), "L": dict(L=100.0, nd=0.39)}
KB = {"C": 95, "L": 80}


def make_stage(A, band="C", spread=1.0, rng=None, target=TARGET_DB, pch=PCH_IN_DBM):
    """Build A stages. Each one gets its own pump operating point and GFF, as in a factory calibration."""
    d = DESIGN[band]
    K = KB[band]
    # nominal pump set point for the fleet: devices differ, the factory GFF absorbs the static spread
    p0 = ph.AmpParams(1, band, L=d["L"], K=K)
    Pin0 = np.full((1, K), 10 ** (pch / 10) * 1e-3)
    lo, hi = np.full(1, 1e-3), np.full(1, 2.0)
    s0 = ph.ZSolver(p0)
    for _ in range(10):
        u = np.sqrt(lo * hi)
        ph.settle(s0, Pin0, u, T=0.006)
        up = s0.nbar() < d["nd"]
        lo, hi = np.where(up, u, lo), np.where(up, hi, u)
    u_nom = np.sqrt(lo * hi)[0]
    p = ph.AmpParams(A, band, L=d["L"], K=K)
    if spread > 0: p.perturb(rng, spread)
    Pin = np.full((A, K), 10 ** (pch / 10) * 1e-3)
    u = np.full(A, u_nom)
    s = ph.ZSolver(p)
    ph.settle(s, Pin, u, T=0.03)
    p.gff_db = s.gain_db(Pin) + p.gff_db - target
    return p, u, s, Pin


class PumpActuator:
    """Delay line, slew limit and first order driver lag between command and launched pump power."""

    def __init__(self, u0, delay, slew, tau_p=20e-6, dt=DT):
        self.nd = max(1, int(round(delay / dt)))
        self.buf = np.tile(u0, (self.nd, 1))
        self.i = 0
        self.u = u0.copy()
        self.slew, self.tau, self.dt = slew, tau_p, dt

    def step(self, cmd):
        out = self.buf[self.i].copy()
        self.buf[self.i] = cmd
        self.i = (self.i + 1) % self.nd
        du = (out - self.u) * (1 - np.exp(-self.dt / self.tau))
        self.u = self.u + np.clip(du, -self.slew * self.dt, self.slew * self.dt)
        return self.u


class Twin:
    """Mean inversion twin: nominal reservoir ODE, optional residual network ensemble, online offset estimate."""

    def __init__(self, p_nom, nets=None, use_phys=True):
        self.use_phys = use_phys
        self.m = ph.ReservoirModel(p_nom)
        self.p = p_nom
        self.nets = nets  # list of (W, b) lists with tanh activations, exported from torch
        self.ucap = 0.5 if p_nom.band == "C" else 1.5

    def feats(self, n, u, P):
        tot = P.sum(1)
        c = (P * np.linspace(-1, 1, P.shape[1])).sum(1) / np.maximum(tot, 1e-12)
        return np.stack([(n - 0.6) * 5, u / self.ucap, tot * 1e3 / 5.0, c], 1)

    def nn(self, x, member=None):
        if not self.nets: return 0.0
        ms = self.nets if member is None else [self.nets[member]]
        out = 0.0
        for net in ms:
            h = x
            for k, (W, b) in enumerate(net):
                h = h @ W + b
                if k < len(net) - 1: h = np.tanh(h)
            out = out + h[:, 0]
        return out / len(ms) * 1e3

    def f(self, n, u, P, member=None):
        out = self.nn(self.feats(n, u, P), member)
        return self.m.f(n, P, u) + out if self.use_phys else out


def load_nets(path):
    d = np.load(path, allow_pickle=True)
    return list(d["nets"])


class AGC:
    """Velocity form PI loop on the measured total power gain."""

    def __init__(self, u0, Kp=0.06, Ki=250.0, Ts=20e-6, umax=2.0):
        self.u, self.Kp, self.Ki, self.Ts, self.umax = u0.copy(), Kp, Ki, Ts, umax
        self.ep = np.zeros_like(u0)

    def update(self, e):
        self.u = np.clip(self.u * (1 + self.Kp * (e - self.ep) + self.Ki * self.Ts * e), 1e-3, self.umax)
        self.ep = e
        return self.u


class MPC:
    """Receding horizon pump planner, linearised and solved per amplifier as a box constrained QP in batch.

    Decision variables are pump moves per block, so the slew limit becomes a simple box.
    """

    def __init__(self, twin, u0, Ts=100e-6, N=30, blocks=(1, 1, 1, 2, 3, 4, 6, 12), slew=1000.0, delay=2e-4,
                 w_e=1.0, w_u=2e-3, w_d=2e-2, kappa=0.0, delta=0.15, tau_p=20e-6, adapt=True, umax=2.0, n_sq=2):
        self.t, self.Ts, self.N, self.blocks = twin, Ts, N, np.array(blocks)
        assert self.blocks.sum() == N
        self.slew, self.delay, self.w_e, self.w_u, self.w_d = slew, delay, w_e, w_u, w_d
        self.kappa, self.delta, self.adapt, self.umax, self.n_sq = kappa, delta, adapt, umax, n_sq
        self.u_ref = u0.copy()
        self.d = np.zeros_like(u0)
        self.plan = np.zeros((len(u0), len(blocks)))
        self.n_prev = None
        self.nd = int(np.ceil(delay / Ts))
        self.hist = np.tile(u0[:, None], (1, max(self.nd, 1)))
        self.sig_h = np.zeros((len(u0), N))
        self.umin = 1e-3

    def rollout(self, n0, us, Ps, dgdn, sens=False, member=None, Ps_alt=None, doff=0.0):
        """Simulate the mean inversion. us: (A,N) command; Ps: list of input arrays per horizon step."""
        A, N = n0.shape[0], self.N
        ns = np.zeros((A, N + 1)); ns[:, 0] = n0
        a = np.ones((A, N)); b = np.zeros((A, N))
        dt = self.Ts
        for i in range(N):
            ui = self.hist[:, i] if i < self.nd else us[:, i - self.nd]
            f0 = self.t.f(ns[:, i], ui, Ps[i], member) + self.d + doff
            if sens:
                eps = 1e-3
                fn = (self.t.f(ns[:, i] + eps, ui, Ps[i], member) - self.t.f(ns[:, i], ui, Ps[i], member)) / eps
                fu = (self.t.f(ns[:, i], ui + 1e-3, Ps[i], member) - self.t.f(ns[:, i], ui, Ps[i], member)) / 1e-3
                # exponential discretisation keeps the stiff scalar stable at the coarse step
                z = np.minimum(fn, -1.0)
                phi = (np.exp(z * dt) - 1) / z
                a[:, i] = np.exp(z * dt); b[:, i] = phi * fu
                ns[:, i + 1] = ns[:, i] + phi * f0
            else:
                fn = (self.t.f(ns[:, i] + 1e-3, ui, Ps[i], member) - self.t.f(ns[:, i], ui, Ps[i], member)) / 1e-3
                z = np.minimum(fn, -1.0)
                ns[:, i + 1] = ns[:, i] + (np.exp(z * dt) - 1) / z * f0
        return (ns, a, b) if sens else ns

    def solve(self, n_meas, u_now, P_now, P_future, t_rel, gain_of_n, g_target, mask, jitter=0.0):
        """t_rel: time to the event per amp (s), negative after it. P_future: input after the event."""
        A, N = n_meas.shape[0], self.N
        tick = self.Ts * np.arange(1, N + 1)
        Ps = [np.where(((t_rel - (tick[i] - self.Ts)) > 0)[:, None], P_now, P_future) for i in range(N)]
        rep = np.repeat(np.arange(len(self.blocks)), self.blocks)
        B = np.eye(len(self.blocks))[rep]  # (N,M) block map
        cumB = np.cumsum(self.blocks) * self.Ts
        step_lim = self.slew * self.blocks * self.Ts
        plan = np.concatenate([self.plan[:, 1:], np.zeros((A, 1))], 1)
        g0, dg = gain_of_n(n_meas)
        for _ in range(self.n_sq):
            u_seq = u_now[:, None] + (np.cumsum(plan, 1) @ B.T)
            u_seq = np.clip(u_seq, self.umin[:, None] if np.ndim(self.umin) else self.umin, self.umax)
            ns, a, b = self.rollout(n_meas, u_seq, Ps, dg, sens=True)
            g, slope = gain_of_n(ns[:, 1:].reshape(-1))
            g = g.reshape(A, N); slope = slope.reshape(A, N)
            # sensitivity of gain to plan moves
            S_n = np.zeros((A, N, N))  # d n_{i+1} / d u_j
            for i in range(N):
                j = i - self.nd
                if i > 0: S_n[:, i, :] = a[:, i, None] * S_n[:, i - 1, :]
                if j >= 0: S_n[:, i, j] += b[:, i]
            cum = np.cumsum(np.eye(len(self.blocks)), 0)
            Mcum = B @ cum  # u_seq moves -> command per step
            S = slope[:, :, None] * (S_n @ Mcum)  # (A,N,M)
            sig = np.zeros((A, N))
            if self.kappa > 0: sig = self.uncertainty(n_meas, u_seq, Ps, gain_of_n, t_rel, P_now, P_future, jitter, g)
            self.sig_h = sig
            ref = g_target[:, None] + np.minimum(self.kappa * sig, 2 * self.delta)
            e0 = g - ref
            # plan is a deviation around current plan: x = plan + dx
            active = (np.abs(e0) + self.kappa * sig > self.delta)
            w = self.w_e * (1 + 4.0 * active)
            r = e0 - (S * plan[:, None, :]).sum(2)  # residual at x=0
            H = (S.transpose(0, 2, 1) * w[:, None, :]) @ S
            c = (S.transpose(0, 2, 1) * w[:, None, :] * r[:, None, :]).sum(2)
            # command deviation from reference costs energy; move size costs wear
            Mc = Mcum.T @ Mcum
            du_ref = u_now - self.u_ref
            H = H + self.w_u * Mc[None] + self.w_d * np.eye(len(self.blocks))[None]
            c = c + self.w_u * (Mcum.sum(0)[None] * du_ref[:, None])
            L = np.maximum(np.linalg.norm(H, ord="fro", axis=(1, 2)), 1e-9)
            x = plan.copy(); y = x.copy(); tk = 1.0
            for _ in range(40):
                gr = (H @ y[:, :, None])[:, :, 0] + c
                xn = np.clip(y - gr / L[:, None], -step_lim, step_lim)
                tn = (1 + np.sqrt(1 + 4 * tk * tk)) / 2
                y = xn + (tk - 1) / tn * (xn - x)
                x, tk = xn, tn
            plan = x
        self.plan = plan
        u_seq = np.clip(u_now[:, None] + (np.cumsum(plan, 1) @ B.T), self.umin[:, None] if np.ndim(self.umin) else self.umin, self.umax)
        cmd = u_seq[:, 0]
        if self.nd > 0:
            self.hist = np.concatenate([self.hist[:, 1:], cmd[:, None]], 1)
        return cmd

    def uncertainty(self, n0, u_seq, Ps, gain_of_n, t_rel, P_now, P_future, jitter, g_nom):
        """Spread of the predicted gain over ensemble members and event time, inflated by the conformal factor."""
        A, N = n0.shape[0], self.N
        out = []
        nets = self.t.nets or []
        u_first = self.hist[:, 0] if self.nd > 0 else u_seq[:, 0]
        f_mean = self.t.f(n0, u_first, Ps[0])
        for m in range(len(nets)):
            # members agree on the measured present, so the spread only reflects what lies ahead
            ns = self.rollout(n0, u_seq, Ps, None, member=m, doff=f_mean - self.t.f(n0, u_first, Ps[0], m))
            out.append(gain_of_n(ns[:, 1:].reshape(-1))[0].reshape(A, N))
        if jitter > 0:
            tick = self.Ts * np.arange(1, N + 1)
            for sgn in (-1, 1):
                P2 = [np.where(((t_rel + sgn * jitter - (tick[i] - self.Ts)) > 0)[:, None], P_now, P_future) for i in range(N)]
                ns = self.rollout(n0, u_seq, P2, None)
                out.append(gain_of_n(ns[:, 1:].reshape(-1))[0].reshape(A, N))
        if not out: return np.zeros((A, N))
        return np.std(np.stack(out + [g_nom]), axis=0)


def steady_pump_nominal(model, n_star, P):
    """Pump power that balances the reservoir ODE at the target inversion for the input P."""
    p = model.p
    G = np.exp(np.clip(model.ea * n_star[:, None] - model.aa, -30, 30))
    Gp = np.exp(-model.ap * (1 - n_star))
    sig = (P * (1 - G) * model.ph).sum(1)
    need = n_star / p.tau * model.vol - sig
    return np.maximum(need, 1e-6) / (p.eta * (1 - Gp) * model.php)


def run_batch(p, u0, sol, Pin0, mask_after, t_event, policy, T_end=0.02, delay=2e-4, slew=1000.0, tau_p=20e-6,
              lead=2e-3, jitter=None, twin=None, mpc_kw=None, agc_kw=None, noise_db=0.01, rng=None, dt=DT,
              t_notice=None, record_every=4, Pin_after=None):
    """Independent amplifiers with their own event. policy in {none, agc, ff, mpc}. Returns gain traces of survivors."""
    A = p.A
    rng = rng or np.random.default_rng(0)
    jitter = np.zeros(A) if jitter is None else jitter  # actual event minus the notified event
    t_true = t_event + jitter
    P_after = Pin0 * mask_after if Pin_after is None else Pin_after
    survivors = mask_after.astype(float)
    act = PumpActuator(u0, delay, slew, tau_p, dt)
    agc = AGC(u0, **(agc_kw or {}))
    nom = twin.m if twin else ph.ReservoirModel(p)
    n_star = None
    cmd = u0.copy()
    sol_gain0 = sol.gain_db(Pin0)
    g_tgt = (sol_gain0 * survivors).sum(1) / survivors.sum(1)
    pd_tgt = 10 * np.log10((Pin0 * 10 ** (sol_gain0 / 10)).sum(1) / Pin0.sum(1))
    # feedforward map uses the nominal model, scaled by the pre event operating point
    n_nom = nom.n_from_gain(sol_gain0, np.ones_like(Pin0, bool))
    ff_ratio = steady_pump_nominal(nom, n_nom, P_after) / steady_pump_nominal(nom, n_nom, Pin0)
    ff_done = np.zeros(A, bool)
    ctrl = None
    if policy == "mpc":
        kw = dict(slew=slew, delay=delay, tau_p=tau_p); kw.update(mpc_kw or {})
        kw.pop("jitter_sig", None)
        ctrl = MPC(twin, u0, **kw)
        ctrl.u_ref = u0 * ff_ratio
        ctrl.umin = 0.1 * u0
    # online offset so that the twin balances at the measured operating point
    d_off = None
    Nsteps = int(T_end / dt)
    ag_steps = max(1, int(round(agc.Ts / dt)))
    mp_steps = int(round((ctrl.Ts if ctrl else 1e-4) / dt))
    rec_g, rec_u, rec_t, rec_nbar = [], [], [], []
    rec_all = []
    jit_sig = (mpc_kw or {}).get("jitter_sig", 0.0)

    def gain_of_n(nv):
        """Mean survivors' gain and slope for a flat array of inversions, with amps repeated along the horizon."""
        nvv = nv.reshape(A, -1)
        e = (4.343 * nom.ea * survivors).sum(1, keepdims=True) / survivors.sum(1, keepdims=True)
        a = ((4.343 * nom.aa + nom.p.gff_db) * survivors).sum(1, keepdims=True) / survivors.sum(1, keepdims=True)
        g = e * nvv - a + g_off[:, None]
        return g.ravel() if nv.size != A else g[:, 0], np.broadcast_to(e, nvv.shape).ravel() if nv.size != A else e[:, 0]

    g_off = np.zeros(A)
    if ctrl is not None:
        n_m = nom.n_from_gain((sol_gain0 * survivors).sum(1, keepdims=True) / survivors.sum(1, keepdims=True), mask_after.astype(bool))
        ctrl.n_prev = n_m.copy()
        ctrl.d = -twin.f(n_m, u0, Pin0) if ctrl.adapt else np.zeros(A)
    energy = np.zeros(A)
    for k in range(Nsteps):
        T = k * dt
        Pin = np.where((T >= t_true)[:, None], P_after, Pin0)
        if k % ag_steps == 0:
            g_now = sol.gain_db(Pin)
            pw = Pin.sum(1)
            pd = 10 * np.log10((Pin * 10 ** (g_now / 10)).sum(1) / pw) + noise_db * rng.standard_normal(A)
            e = pd_tgt - pd
            if policy in ("agc", "ff"):
                cmd = agc.update(e)
            if policy == "ff":
                fire = (T >= t_event - delay) & ~ff_done
                if fire.any():
                    agc.u = np.where(fire, agc.u * ff_ratio, agc.u); ff_done |= fire
                    cmd = agc.u.copy()
            if policy == "mpc":
                # outside the planning window the loop falls back to the PI trim
                window = (T >= t_event - lead) & (T <= t_event + 8e-3)
                agc.u = np.where(window, cmd, agc.update(e))
                cmd = np.where(window, cmd, agc.u)
        if policy == "mpc" and k % mp_steps == 0:
            window = (T >= t_event - lead) & (T <= t_event + 8e-3)
            if window.any():
                g_sv = (sol.gain_db(Pin) * survivors).sum(1) / survivors.sum(1) + 0.03 * rng.standard_normal(A)
                n_m = nom.n_from_gain(g_sv[:, None], mask_after.astype(bool))
                if ctrl.adapt:
                    # innovation over the last tick trains the slow offset, only away from the event
                    pred = ctrl.n_prev + ctrl.Ts * (twin.f(ctrl.n_prev, act.u, Pin) + ctrl.d)
                    far = np.abs(T - t_event) > 1e-3
                    ctrl.d = np.clip(ctrl.d + np.where(far, 0.05, 0.0) * (n_m - pred) / ctrl.Ts, -3e3, 3e3)
                ctrl.n_prev = n_m.copy()
                g_off = g_sv - gain_of_n(n_m)[0] + g_off
                P_known = np.where((T >= t_event)[:, None], P_after, Pin0)
                new = ctrl.solve(n_m, cmd, P_known, P_after, t_event - T, gain_of_n, g_tgt, mask_after, jitter=jit_sig)
                cmd = np.where(window, new, cmd)
        u = act.step(cmd)
        sol.step(Pin, u, dt)
        energy += u * dt
        if k % record_every == 0:
            g = sol.gain_db(Pin)
            rec_g.append((g * survivors).sum(1) / survivors.sum(1))
            rec_u.append(u.copy()); rec_t.append(T)
    return dict(t=np.array(rec_t), g=np.stack(rec_g, 1), u=np.stack(rec_u, 1), g_tgt=g_tgt, energy=energy, t_event=t_event,
                sig=(ctrl.sig_h if ctrl else None))


def kpis(res, tol_db=0.2):
    t, g, tgt = res["t"], res["g"], res["g_tgt"]
    dev = g - tgt[:, None]
    peak = np.abs(dev).max(1)
    pos = dev.max(1); neg = dev.min(1)
    settle = np.zeros(len(tgt))
    for i in range(len(tgt)):
        out = np.where(np.abs(dev[i]) > tol_db)[0]
        settle[i] = 0.0 if len(out) == 0 else max(t[out[-1]] - res["t_event"][i], 0.0)
    return dict(peak=peak, pos=pos, neg=neg, settle_ms=settle * 1e3, energy_mJ=res["energy"] * 1e3)
