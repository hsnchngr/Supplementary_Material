"""Planner scaling: wall time of one MPC update when the stages of one or more lines are solved in one batch.

Output: sonuclar/planner_scaling.json with the median time per update for each batch size, deterministic (kappa=0)
and uncertainty aware (kappa=2, ensemble and jitter rollouts).
"""
import sys, json, time
sys.path.insert(0, "kod")
import numpy as np
import sim, ctrl

gff = np.load("data/trans_C_train.npz")["gff"]
out = {}
for A in (1, 4, 16, 64, 256):
    rng = np.random.default_rng(7)
    p, u, sol, Pin = sim.make_stage(A, "C", spread=1.0, rng=rng)
    K = p.K
    surv = np.zeros((A, K), bool)
    for i in range(A): surv[i, rng.permutation(K)[: K // 2]] = True
    P1 = Pin * surv
    twin = ctrl.load_twin("C", A, gff, kind="hybrid")
    nom = twin.m
    g0 = sol.gain_db(Pin)
    e = (4.343 * nom.ea * surv).sum(1, keepdims=True) / surv.sum(1, keepdims=True)
    a = ((4.343 * nom.aa + nom.p.gff_db) * surv).sum(1, keepdims=True) / surv.sum(1, keepdims=True)

    def gain_of_n(nv):
        nvv = nv.reshape(A, -1); g = e * nvv - a
        return (g.ravel(), np.broadcast_to(e, nvv.shape).ravel()) if nv.size != A else (g[:, 0], e[:, 0])

    n_m = nom.n_from_gain((g0 * surv).sum(1, keepdims=True) / surv.sum(1, keepdims=True), surv)
    tgt = (g0 * surv).sum(1) / surv.sum(1)
    res = {}
    for kappa in (0.0, 2.0):
        m = sim.MPC(twin, u, delay=2e-4, kappa=kappa)
        m.u_ref = u.copy(); m.umin = 0.1 * u
        ts = []
        for k in range(12):
            t_rel = np.full(A, 1e-3 - k * 1e-4)
            t0 = time.perf_counter()
            m.solve(n_m, u, Pin, P1, t_rel, gain_of_n, tgt, surv, jitter=1e-4 if kappa else 0.0)
            ts.append(time.perf_counter() - t0)
        res[f"kappa{kappa:g}_ms"] = float(np.median(ts[2:]) * 1e3)
    out[A] = res
    print(A, {k: round(v, 2) for k, v in res.items()}, flush=True)
json.dump(out, open("sonuclar/planner_scaling.json", "w"), indent=1)
