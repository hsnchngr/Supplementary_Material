"""External checks that never touched training: COSMOS multi span cascades and the 2026 campaign restricted to zero tilt settings."""
import json, re, sys, importlib.util as iu
import numpy as np, torch
sp = iu.spec_from_file_location("st", "kod/02_steady.py"); st = iu.module_from_spec(sp); sp.loader.exec_module(st)
DEVS = ['rdm1-co1', 'rdm2-co1', 'rdm3-co1', 'rdm4-co1', 'rdm5-co1', 'rdm6-co1', 'rdm1-lg1', 'rdm2-lg1']


def fleet(typ, dev="rdm1-co1"):
    c = json.load(open(f"sonuclar/core_{typ}_{dev}.json"))
    core = {float(k): dict(b=np.array(v["b"]), D=np.array(v["D"]), delta=v["delta"]) for k, v in c.items()}
    nets = []
    for sd in torch.load(f"sonuclar/steady_{typ}_{dev}.pt"):
        n = st.Net(); n.load_state_dict(sd); n.eval(); nets.append(n)
    return core, nets


def spec(d): return np.array([d[str(i)] for i in range(1, 96)], np.float32)


models = {t: fleet(t) for t in ("booster", "preamp")}
out = dict(multispan={})
for topo in (1, 2, 3):
    D = json.load(open(f"data/cosmos/dataset/multispan/multispan_topology{topo}.json"))
    stages = sorted({k[:-3] for k in D[0] if k.endswith("EDFA") is False and k.endswith("In")}, key=lambda s: (int(re.search(r"roadm_(\d+)", s).group(1)), "preamp" in s is False))
    seq = []
    for k in D[0]:
        if k.endswith("In"): seq.append(k[:-2])
    errs = []
    for m in D:
        mask = np.zeros(95, bool); mask[np.array(m["open_channel_list"]) - 1] = True
        cum_true, cum_pred = np.zeros(95), np.zeros(95); row = []
        for s in seq:
            typ = "booster" if "booster" in s else "preamp"
            info = m[s + "EDFA"]; gt = float(info["target_gain"])
            core, nets = models[typ]
            if gt not in core: row.append(np.nan); continue
            pin, pout = spec(m[s + "In"]), spec(m[s + "Out"])
            d = dict(pin=pin[None], pout=pout[None], mask=mask[None], gt=np.array([gt], np.float32), ptin=np.array([info["input_power"]], np.float32))
            pr = st.core_predict(core, d) + st.predict(nets, st.features(d)).mean(0)
            cum_true += pout - pin; cum_pred += pr[0]
            row.append(float(np.abs(cum_pred - cum_true)[mask].mean()))
        errs.append(row)
    E = np.array(errs, float)
    # the first stage error is the single device error; later entries show how a fleet model accumulates along the path
    out["multispan"][topo] = dict(stages=seq, n=len(D), cum_mae=np.nanmean(E, 0).tolist())
    print(topo, len(D), seq, np.round(np.nanmean(E, 0), 3), flush=True)
# 2026 campaign: only 18 dB with zero tilt, files from the first sessions
E = st.load("data/parsed_live2026.npz")
rec = {}
for typ in ("booster", "preamp"):
    a = []
    for dev in DEVS:
        i = np.where((E["dev"] == dev) & (E["typ"] == typ) & (E["gt"] == 18.0))[0]
        if len(i) < 20: continue
        d = st.sub(E, i); core, nets = fleet(typ, dev)
        rngi = np.random.default_rng(0).permutation(len(i))
        c, t = st.sub(d, rngi[:20]), st.sub(d, rngi[20:])
        if len(t["gt"]) == 0: continue
        pt = st.core_predict(core, t) + st.predict(nets, st.features(t)).mean(0)
        pc = st.core_predict(core, c) + st.predict(nets, st.features(c)).mean(0)
        db = st.bias_update(st.gains(c) - pc, c["mask"].astype(float))
        a.append((st.metrics(pt, st.gains(t), t["mask"], t["gt"])["mae"], st.metrics(pt + db, st.gains(t), t["mask"], t["gt"])["mae"], float(np.median(d["ptin"])), len(t["gt"])))
    rec[typ] = dict(zero=float(np.mean([x[0] for x in a])), few20=float(np.mean([x[1] for x in a])), ptin=float(np.mean([x[2] for x in a])), n=int(np.sum([x[3] for x in a])), devices=len(a))
    print(typ, rec[typ])
for typ in ("booster", "preamp"):
    Dd = st.load(f"data/parsed_{typ}.npz"); rec[typ]["ptin_train_p1_p99"] = np.percentile(Dd["ptin"], [1, 99]).tolist()
    print(typ, rec[typ]["ptin_train_p1_p99"])
out["live2026_18dB"] = rec
json.dump(out, open("sonuclar/external.json", "w"))
