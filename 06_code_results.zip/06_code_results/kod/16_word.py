"""Word versions of the paper and of the supplement in the IEEE Transactions layout.

US letter, Times New Roman 10 pt, title block over the full width, two column body, IEEE style headings (I., A.),
numbered equations, figure and table captions, IEEE reference list. Figures are inserted at column width; their final
placement is left to the authors. Run after kod/15_package.py (it needs gonderim_TNSM/package_report.json):
    python kod/16_word.py
"""
import os, re, json, subprocess, zipfile, shutil, tempfile

ROOT = os.getcwd()
PKG = os.path.join(ROOT, "gonderim_TNSM")
MK = os.path.join(ROOT, "makale")
REP = json.load(open(os.path.join(PKG, "package_report.json"), encoding="utf8"))
ROMAN = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII"]
FONT = '<w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:cs="Times New Roman" w:eastAsia="Times New Roman"/>'
PAGE = '<w:pgSz w:w="12240" w:h="15840"/><w:pgMar w:top="1080" w:right="965" w:bottom="1440" w:left="965" w:header="720" w:footer="720" w:gutter="0"/>'
SECT2 = '<w:sectPr><w:type w:val="continuous"/>' + PAGE + '<w:cols w:num="2" w:space="230"/></w:sectPr>'
BREAK1 = '<w:p><w:pPr><w:sectPr><w:type w:val="continuous"/>' + PAGE + '<w:cols w:num="1"/></w:sectPr></w:pPr></w:p>'


def group(s, i):
    """Text of the balanced {...} group that opens at s[i]."""
    assert s[i] == "{"
    d, j = 0, i
    while True:
        d += s[j] == "{"; d -= s[j] == "}"
        if d == 0: return s[i + 1:j]
        j += 1


def prep(name, labels, sprefix):
    s = open(os.path.join(MK, name + ".tex"), encoding="utf8").read()
    title = group(s, s.index(r"\title{") + 6)
    thanks = [group(s, m.end() - 1) for m in re.finditer(r"\\thanks\{", s)]
    authors = r"Hasan Cihangir and Harun \c{C}i\u{g}"
    if len(thanks) >= 2:
        authors = r"Hasan Cihangir\footnote{" + thanks[0] + r"} and Harun \c{C}i\u{g}\footnote{" + thanks[1] + "}"
    head = "\\documentclass{article}\n\\usepackage{amsmath,amssymb,graphicx}\n\\newcommand{\\Cnet}{C_{\\mathrm{net}}}\n\\title{" + title + "}\n\\author{" + authors + "}\n\\begin{document}\n"
    if r"\begin{abstract}" in s:
        ab = s[s.index(r"\begin{abstract}") + 16:s.index(r"\end{abstract}")].strip()
        kw = s[s.index(r"\begin{IEEEkeywords}") + 20:s.index(r"\end{IEEEkeywords}")].strip()
        head += "\\begin{abstract}\n\\textit{Abstract}---" + ab + "\n\\end{abstract}\n\\maketitle\n\n\\textbf{\\textit{Index Terms}---" + kw + "}\n\n"
        body = s[s.index(r"\end{IEEEkeywords}") + 18:]
    else:
        head += "\\maketitle\n\n"
        body = s[s.index(r"\maketitle") + 10:]
    body = re.sub(r"\\IEEEPARstart\{(\w)\}\{(\w+)\}", r"\1\2", body)
    body = re.sub(r"\\ref\{M:([^}]+)\}", lambda m: REP["labels_main"][m.group(1)], body)
    body = re.sub(r"\\ref\{([^}]+)\}", lambda m: labels[m.group(1)], body)
    body = re.sub(r"\s*\\label\{(eq:[^}]+)\}", lambda m: r" \qquad\text{(" + labels[m.group(1)] + ")}", body)
    body = re.sub(r"\\label\{[^}]+\}", "", body)
    body = re.sub(r"\\mbox\{([^{}]*)\}", r"\1", body)
    body = re.sub(r"\\shortstack\[l\]\{([^{}]*)\}", lambda m: m.group(1).replace("\\\\", " "), body)
    body = re.sub(r"\\item\[(C\d)\]", r"\\item \1.", body)
    body = re.sub(r"\\includegraphics(\[[^\]]*\])?\{([^}]+)\.pdf\}", r"\\includegraphics[width=3.4in]{\2.png}", body)
    body = body.replace("figure*", "figure").replace("table*", "table").replace("{\\sloppy ", "{")
    body = body.replace("\\bibliographystyle{IEEEtran}\n", "").replace("\\bibliography{refs}", "\\section*{References}")
    out, sec, sub, nf, nt, env = [], 0, 0, 0, 0, None
    for l in body.split("\n"):
        if l.startswith("\\section{"):
            sec += 1; sub = 0
            l = "\\section{" + sprefix + ROMAN[sec - 1] + ". " + l[9:]
        elif l.startswith("\\subsection{"):
            sub += 1
            l = "\\subsection{" + chr(64 + sub) + ". " + l[12:]
        elif l.startswith("\\begin{figure"): env = "f"
        elif l.startswith("\\begin{table"): env = "t"
        elif l.startswith("\\caption{"):
            if env == "f":
                nf += 1; l = "\\caption{Fig.~" + (sprefix[:1] + str(nf)) + ". " + l[9:]
            else:
                nt += 1; l = "\\caption{TABLE " + sprefix + ROMAN[nt - 1] + ". " + l[9:]
        out.append(l)
    return head + "\n".join(out)


def reference_doc(tmp):
    ref = os.path.join(tmp, "ref.docx")
    with open(ref, "wb") as f:
        f.write(subprocess.run(["pandoc", "--print-default-data-file", "reference.docx"], stdout=subprocess.PIPE, check=True).stdout)
    z = zipfile.ZipFile(ref); files = {n: z.read(n) for n in z.namelist()}; z.close()
    st = files["word/styles.xml"].decode("utf8")
    st = re.sub(r"<w:rPrDefault>.*?</w:rPrDefault>", '<w:rPrDefault><w:rPr>' + FONT + '<w:sz w:val="20"/><w:szCs w:val="20"/><w:lang w:val="en-US"/></w:rPr></w:rPrDefault>', st, flags=re.S)

    def style(sid, ppr, rpr):
        nonlocal st
        m = re.search(r'<w:style [^>]*w:styleId="' + sid + r'"[^>]*>.*?</w:style>', st, flags=re.S)
        if not m:
            print("  style not in reference doc:", sid); return
        b = re.sub(r"<w:pPr>.*?</w:pPr>|<w:rPr>.*?</w:rPr>|<w:pPr/>|<w:rPr/>", "", m.group(0), flags=re.S)
        b = b.replace("</w:style>", "<w:pPr>" + ppr + "</w:pPr><w:rPr>" + FONT + rpr + '<w:color w:val="000000"/></w:rPr></w:style>')
        st = st[:m.start()] + b + st[m.end():]
    sz = lambda n: f'<w:sz w:val="{n}"/><w:szCs w:val="{n}"/>'
    off = '<w:b w:val="0"/><w:bCs w:val="0"/>'
    style("Normal", '<w:spacing w:before="0" w:after="0" w:line="240" w:lineRule="auto"/><w:jc w:val="both"/>', sz(20))
    style("BodyText", '<w:spacing w:before="0" w:after="0"/><w:ind w:firstLine="202"/><w:jc w:val="both"/>', sz(20))
    style("FirstParagraph", '<w:spacing w:before="0" w:after="0"/><w:ind w:firstLine="0"/><w:jc w:val="both"/>', sz(20))
    style("Compact", '<w:spacing w:before="0" w:after="0"/>', sz(18))
    style("Title", '<w:spacing w:before="0" w:after="240"/><w:jc w:val="center"/>', sz(48) + off)
    style("Author", '<w:spacing w:before="0" w:after="240"/><w:jc w:val="center"/>', sz(22) + off)
    style("Abstract", '<w:spacing w:before="0" w:after="120"/><w:ind w:firstLine="202"/><w:jc w:val="both"/>', sz(18) + '<w:b/><w:bCs/>')
    style("Heading1", '<w:keepNext/><w:spacing w:before="240" w:after="80"/><w:jc w:val="center"/><w:outlineLvl w:val="0"/>', sz(20) + off + '<w:smallCaps/>')
    style("Heading2", '<w:keepNext/><w:spacing w:before="120" w:after="60"/><w:jc w:val="left"/><w:outlineLvl w:val="1"/>', sz(20) + off + '<w:i/><w:iCs/>')
    style("Heading3", '<w:keepNext/><w:spacing w:before="120" w:after="60"/><w:jc w:val="left"/><w:outlineLvl w:val="2"/>', sz(20) + off + '<w:i/><w:iCs/>')
    for sid in ("Caption", "ImageCaption", "TableCaption"):
        style(sid, '<w:spacing w:before="60" w:after="120"/><w:jc w:val="both"/>', sz(16) + '<w:i w:val="0"/><w:iCs w:val="0"/>')
    style("Bibliography", '<w:spacing w:before="0" w:after="0"/><w:ind w:left="360" w:hanging="360"/><w:jc w:val="both"/>', sz(16))
    style("FootnoteText", '<w:spacing w:before="0" w:after="0"/><w:jc w:val="both"/>', sz(16))
    files["word/styles.xml"] = st.encode("utf8")
    with zipfile.ZipFile(ref, "w", zipfile.ZIP_DEFLATED) as z:
        for n, d in files.items(): z.writestr(n, d)
    return ref


def columns(docx):
    """Title block in one column, everything after the author line in two columns."""
    z = zipfile.ZipFile(docx); files = {n: z.read(n) for n in z.namelist()}; z.close()
    x = files["word/document.xml"].decode("utf8")
    x = re.sub(r'<w:p>(?:(?!</w:p>).)*?w:val="AbstractTitle"(?:(?!</w:p>).)*?</w:p>', "", x, count=1, flags=re.S)
    i = x.find('w:val="Author"')
    if i < 0: i = x.find('w:val="Title"')
    e = x.index("</w:p>", i) + 6
    x = x[:e] + BREAK1 + x[e:]
    x, k = re.subn(r"<w:sectPr(?: [^>]*)?(?:/>|>(?:(?!<w:sectPr).)*?</w:sectPr>)\s*</w:body>", SECT2 + "</w:body>", x, flags=re.S)
    assert k == 1, "final section not found"
    files["word/document.xml"] = x.encode("utf8")
    with zipfile.ZipFile(docx, "w", zipfile.ZIP_DEFLATED) as z:
        for n, d in files.items(): z.writestr(n, d)
    return x.count("<w:drawing>"), x.count('w:val="Heading1"')


tmp = tempfile.mkdtemp()
try:
    ref = reference_doc(tmp)
    jobs = [("main", REP["labels_main"], "", os.path.join(PKG, "01_manuscript", "Cihangir_Cig_TNSM_manuscript.docx")),
            ("supplement", REP["labels_supplement"], "S-", os.path.join(PKG, "02_supplementary", "Cihangir_Cig_TNSM_supplementary.docx"))]
    for name, labels, sp, dst in jobs:
        src = os.path.join(tmp, name + ".tex")
        open(src, "w", encoding="utf8").write(prep(name, labels, sp))
        r = subprocess.run(["pandoc", src, "-f", "latex", "-t", "docx", "-o", dst, "--citeproc", "--bibliography", os.path.join(MK, "refs.bib"),
                            "--csl", os.path.join(MK, "ieee.csl"), "--reference-doc", ref, "--resource-path", os.path.join(ROOT, "sekiller")],
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, errors="replace", timeout=600)
        if r.stdout.strip(): print("  pandoc:", r.stdout.strip()[:600])
        nimg, nh = columns(dst)
        print(f"{os.path.basename(dst)}: {nimg} figures, {nh} sections, {os.path.getsize(dst) / 1e6:.1f} MB")
    shutil.copy2(jobs[0][3], os.path.join(MK, "Makale_8_TNSM.docx"))
    shutil.copy2(jobs[1][3], os.path.join(MK, "Makale_8_TNSM_supplement.docx"))
finally:
    shutil.rmtree(tmp, ignore_errors=True)
