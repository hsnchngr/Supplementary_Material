"""Single stage control study on unseen devices: drops, adds, lead time, latency, slew, jitter, ablations, solver convergence."""
import os, sys, json, time, copy
os.environ.setdefault("OMP_NUM_THREADS", "1"); os.environ.setdefault("MKL_NUM_THREADS", "1")
sys.path.insert(0, "kod")
import numpy as np
import physics as ph, sim, ctrl
from multiprocessing import get_context
A = 32
BL = {10: (1, 1, 1, 2, 5), 20: (1, 1, 1, 2, 3, 4, 8), 30: (1, 1, 1, 2, 3, 4, 6, 12), 60: (1, 1, 1, 2, 3, 4, 6, 12, 30)}


def prep(band, drop, kind, seed, spread):
    """Fresh devices settled on the pre event load at the target gain. kind: drop or add."""
    rng = np.random.default_rng(seed)
    p, u, sol, Pin = sim.make_stage(A, band, spread=spread, rng=rng)
    K = p.K
    surv = np.zeros((A, K), bool)
    for i in range(A): surv[i, rng.permutation(K)[: int(round(K * (1 - drop)))]] = True
    P_full, P_s = Pin, Pin * surv
    P0, P1 = (P_full, P_s) if kind == "drop" else (P_s, P_full)
    if kind == "add":
        tg = sim.TARGET_DB
        for _ in range(30):
            ph.settle(sol, P0, u, T=0.0006, dt=20e-6)
            g = (sol.gain_db(P0) * surv).sum(1) / surv.sum(1)
            u = np.clip(u * (1 + 0.12 * (tg - g)), 1e-3, 2.0)
        ph.settle(sol, P0, u, T=0.004, dt=20e-6)
    return p, u, sol, P0, P1, surv, rng


def run(c):
    band = c.get("band", "C")
    gff = np.load(f"data/trans_{band}_train.npz")["gff"]
    seed = c.get("seed", 500)
    p, u, sol, P0, P1, surv, rng = prep(band, c.get("drop", 0.5), c.get("kind", "drop"), seed, c.get("spread", 1.0))
    twin = ctrl.load_twin(band, A, gff, kind=c.get("twin", "hybrid")) if c["policy"] == "mpc" else None
    mk = dict(c.get("mpc_kw", {}))
    if "N" in c:
        mk["N"] = c["N"]; mk["blocks"] = BL[c["N"]]
    jit = rng.normal(0, c.get("jitter", 0.0), A) if c.get("jitter", 0) > 0 else None
    t0 = time.time()
    r = ctrl.run_stage(p, u, sol, P0, P1, surv, np.full(A, 5e-3), c["policy"], T_end=0.02, delay=c.get("delay", 2e-4), slew=c.get("slew", 1000.0),
                       lead=c.get("lead", 2e-3), jitter=jit, twin=twin, mpc_kw=mk, agc_kw=c.get("agc"), rng=rng)
    wall = time.time() - t0
    k = sim.kpis(r)
    dev = r["g"] - r["g_tgt"][:, None]
    over = (np.abs(dev) > 0.5).mean(1) * r["t"][-1] * 1e3
    out = {m: float(np.mean(v)) for m, v in k.items()}
    out.update({m + "_std": float(np.std(v)) for m, v in k.items()})
    out["over05_ms"] = float(np.mean(over)); out["wall_s"] = wall
    out["peak_p95"] = float(np.percentile(k["peak"], 95)); out["peak_max"] = float(k["peak"].max())
    out["neg_p95"] = float(np.percentile(-k["neg"], 95))
    c2 = dict(c); c2.update(out)
    if c.get("save"):
        np.savez(f"sonuclar/ctrl_trace_{c['save']}.npz", t=r["t"], g=r["g"].astype(np.float32), u=r["u"].astype(np.float32), tgt=r["g_tgt"])
    return c2


def convergence():
    """Time step and grid convergence of the reference solver, 50 percent drop on the nominal device."""
    rng = np.random.default_rng(0)
    res = []
    ref = None
    for dt, Nz, nb in ((1e-6, 48, 19), (2e-6, 24, 13), (5e-6, 12, 7), (10e-6, 12, 7), (20e-6, 12, 7), (5e-6, 6, 7), (5e-6, 24, 7), (5e-6, 12, 3), (5e-6, 12, 19)):
        p, u, _, Pin = sim.make_stage(1, "C", spread=0.0, rng=rng)
        m = np.ones((1, 95)); m[:, ::2] = 0
        s = ph.ZSolver(p, Nz=Nz, nbins=nb)
        ph.settle(s, Pin, u, T=0.03, dt=min(dt * 2, 1e-5))
        g0 = s.gain_db(Pin).mean()
        t, g = [], []
        P = Pin * m; t0 = time.time()
        for k in range(int(0.006 / dt)):
            s.step(P, u, dt)
            g.append((s.gain_db(P) * m).sum() / m.sum()); t.append((k + 1) * dt)
        t, g = np.array(t), np.array(g)
        grid_t = np.linspace(2e-5, 0.006, 300)
        gi = np.interp(grid_t, t, g)
        if ref is None: ref = gi
        res.append(dict(dt=dt, Nz=Nz, nb=nb, rms=float(np.sqrt(((gi - ref) ** 2).mean())), maxe=float(np.abs(gi - ref).max()), peak=float(g.max() - g0), t63_us=float(t[np.argmax(g - g[0] >= 0.63 * (g[-1] - g[0]))] * 1e6), wall=time.time() - t0, g0=float(g0)))
        print(res[-1], flush=True)
    return res


if __name__ == "__main__":
    jobs = []
    which = sys.argv[1] if len(sys.argv) > 1 else "all"
    if which in ("tune", "all"):
        tune = [dict(group="tune", policy="agc", drop=0.5, agc=dict(Kp=kp, Ki=ki)) for kp in (0.02, 0.06, 0.15, 0.3) for ki in (100.0, 250.0, 600.0, 1500.0)]
        with get_context("spawn").Pool(16) as pool: R = pool.map(run, tune)
        for r in R: print({k: round(r[k], 3) for k in ("peak", "settle_ms", "over05_ms", "peak_max")}, r["agc"])
        # lowest settling without ringing beyond the first peak
        best = min(R, key=lambda r: r["settle_ms"] + 2 * r["over05_ms"] + 5 * max(0, r["neg_p95"] - 0.3))
        json.dump(dict(agc=best["agc"], all=R), open("sonuclar/agc_tune.json", "w"))
        print("best", best["agc"])
    if which == "tune": sys.exit()
    agc = json.load(open("sonuclar/agc_tune.json"))["agc"]
    def J(**k):
        k.setdefault("agc", agc); jobs.append(k)
    pols = [("none", {}), ("agc", {}), ("ff", {}), ("mpc", {})]
    for drop in (0.1, 0.2, 0.3, 0.5, 0.65, 0.8):
        for pol, _ in pols:
            J(group="drop", policy=pol, drop=drop, save=f"{pol}_{int(drop*100)}" if drop in (0.5, 0.8) else None)
    for drop in (0.5, 0.8):
        for pol, _ in pols[1:]: J(group="add", policy=pol, drop=drop, kind="add", save=f"add_{pol}_{int(drop*100)}" if drop == 0.5 else None)
    for band in ("L",):
        for drop in (0.5, 0.8):
            for pol, _ in pols[1:]: J(group="drop_L", policy=pol, drop=drop, band=band)
    for lead in (0.0, 0.25e-3, 0.5e-3, 1e-3, 2e-3, 3e-3, 5e-3):
        for delay in (2e-5, 5e-5, 1e-4, 2e-4, 5e-4, 1e-3, 2e-3):
            J(group="heat", policy="mpc", lead=lead, delay=delay)
    for delay in (2e-5, 5e-5, 1e-4, 2e-4, 5e-4, 1e-3, 2e-3):
        J(group="heat_agc", policy="agc", delay=delay); J(group="heat_ff", policy="ff", delay=delay)
    for slew in (200.0, 500.0, 1000.0, 2000.0, 5000.0, 20000.0):
        for pol in ("agc", "ff", "mpc"):
            for drop in (0.5, 0.8): J(group="slew", policy=pol, slew=slew, drop=drop)
    for jit in (0.0, 5e-5, 1e-4, 2e-4, 5e-4):
        J(group="jit", policy="ff", jitter=jit, name="FF")
        J(group="jit", policy="mpc", jitter=jit, name="MPC det")
        for kap in (1.0, 2.0, 3.0):
            J(group="jit", policy="mpc", jitter=jit, name=f"UA k{kap:.0f}", mpc_kw=dict(kappa=kap, jitter_sig=max(jit, 5e-5)))
    for name, kw in (("full", dict(twin="hybrid")), ("no_nn", dict(twin="phys")), ("no_adapt", dict(twin="hybrid", mpc_kw=dict(adapt=False))),
                     ("no_adapt_no_nn", dict(twin="phys", mpc_kw=dict(adapt=False))), ("no_phys", dict(twin="node"))):
        for sp in (1.0, 2.0):
            J(group="abl", policy="mpc", name=name, spread=sp, **kw)
    for sp in (0.0, 1.0, 2.0):
        for pol in ("agc", "ff"): J(group="abl", policy=pol, name=pol, spread=sp)
    for N in (10, 20, 30, 60):
        J(group="horizon", policy="mpc", N=N, lead=max(2e-3, N * 1e-4))
    t0 = time.time()
    with get_context("spawn").Pool(20) as pool:
        res = []
        for i, r in enumerate(pool.imap(run, jobs)):
            res.append(r)
            if i % 20 == 0: print(i, len(jobs), int(time.time() - t0), r["group"], r["policy"], round(r["peak"], 2), round(r["settle_ms"], 2), flush=True)
    json.dump(res, open("sonuclar/control.json", "w"))
    json.dump(convergence(), open("sonuclar/convergence.json", "w"))
