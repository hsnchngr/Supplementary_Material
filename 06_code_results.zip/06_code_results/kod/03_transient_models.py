"""Tier 2: transient prediction benchmark against the z resolved reference. Plant and twin differ in structure and parameters."""
import os, sys, json, time
os.environ.setdefault("OMP_NUM_THREADS", "2"); os.environ.setdefault("MKL_NUM_THREADS", "2")
sys.path.insert(0, "kod")
import numpy as np, torch, torch.nn as nn
import physics as ph, sim
from multiprocessing import get_context
torch.set_num_threads(2)
DS = 50e-6  # sampling of the training traces
HC = 6.62607015e-34


def gen_traces(band, A, seed, T=0.025, spread=1.0, fixed_drop=None):
    """Random pump and load schedules on unseen devices. Survivors stay on, the rest switch per event."""
    rng = np.random.default_rng(seed)
    p, u0, sol, Pin = sim.make_stage(A, band, spread=spread, rng=rng)
    K = p.K
    surv = rng.random((A, K)) < rng.uniform(0.15, 0.7, (A, 1))
    surv[np.arange(A), rng.integers(0, K, A)] = True
    if fixed_drop is not None:
        surv = np.zeros((A, K), bool)
        for i in range(A):
            surv[i, rng.permutation(K)[: int(round(K * (1 - fixed_drop)))]] = True
    others = ~surv
    on = others & (rng.random((A, K)) < (1.0 if fixed_drop is not None else rng.uniform(0.3, 1.0, (A, 1))))
    rip = 10 ** (rng.uniform(-0.5, 0.5, (A, 1)) * np.linspace(-1, 1, K) / 10)
    base = Pin * rip
    P = base * (surv | on)
    u = u0 * (np.ones(A) if fixed_drop is not None else rng.uniform(0.7, 1.2, A))
    ph.settle(sol, P, u, T=0.02)
    ns = int(T / sim.DT); every = int(round(DS / sim.DT))
    Y, U, PP = [], [], []
    te = 5e-3 if fixed_drop is not None else None
    next_ev = np.full(A, 0.0) + rng.uniform(1e-3, 6e-3, A)
    for k in range(ns):
        t = k * sim.DT
        if fixed_drop is not None:
            if abs(t - te) < sim.DT / 2: P = base * surv
        else:
            ev = t >= next_ev
            if ev.any():
                idx = np.where(ev)[0]
                for i in idx:
                    if rng.random() < 0.55:
                        on[i] = others[i] & (rng.random(K) < rng.uniform(0.0, 1.0))
                        P[i] = base[i] * (surv[i] | on[i])
                    else:
                        u[i] = u0[i] * rng.uniform(0.6, 1.3)
                next_ev[idx] = t + rng.uniform(1e-3, 6e-3, len(idx))
        if k % every == 0:
            g = sol.gain_db(P)
            Y.append((g * surv).sum(1) / surv.sum(1)); U.append(u.copy()); PP.append(P.astype(np.float32))
        sol.step(P, u, sim.DT)
    return dict(y=np.stack(Y, 1).astype(np.float32), u=np.stack(U, 1).astype(np.float32), P=np.stack(PP, 1), surv=surv)


class Phys:
    """Torch copy of the nominal reservoir model."""

    def __init__(self, band, gff):
        d = sim.DESIGN[band]
        p = ph.AmpParams(1, band, L=d["L"], K=sim.KB[band])
        p.gff_db = gff[None]
        m = ph.ReservoirModel(p)
        self.ea, self.aa = torch.tensor(m.ea[0], dtype=torch.float32), torch.tensor(m.aa[0], dtype=torch.float32)
        self.ap, self.php, self.vol, self.tau = float(m.ap[0]), m.php, float(m.vol[0]), float(p.tau[0])
        self.ph = torch.tensor(m.ph[0] * 1e-18, dtype=torch.float32)
        self.gff = torch.tensor(p.gff_db[0], dtype=torch.float32)
        self.ucap = 0.5 if band == "C" else 1.5

    def f(self, n, P, u):
        G = torch.exp(torch.clamp(self.ea * n[..., None] - self.aa, -30, 30))
        Gp = torch.exp(-self.ap * (1 - n))
        fl = (P * (1 - G) * self.ph).sum(-1) * 1e18 + u * (1 - Gp) * self.php
        return -n / self.tau + fl / self.vol

    def feats(self, n, u, P):
        tot = P.sum(-1)
        c = (P * torch.linspace(-1, 1, P.shape[-1])).sum(-1) / torch.clamp(tot, min=1e-12)
        return torch.stack([(n - 0.6) * 5, u / self.ucap, tot * 1e3 / 5.0, c], -1)

    def e_a(self, surv):
        w = surv.float()
        e = 4.343 * (self.ea * w).sum(-1) / w.sum(-1)
        a = 4.343 * ((self.aa + self.gff / 4.343) * w).sum(-1) / w.sum(-1)
        return e, a


def mlp(ni, no=1, w=48, d=2, act=nn.Tanh, zero_last=True):
    L = [nn.Linear(ni, w), act()]
    for _ in range(d - 1): L += [nn.Linear(w, w), act()]
    L.append(nn.Linear(w, no))
    net = nn.Sequential(*L)
    if zero_last:
        nn.init.zeros_(net[-1].weight); nn.init.zeros_(net[-1].bias)
    return net


def rollout(ph_m, net, batch, mode, sub=2):
    """Integrate the inversion with RK4 from the measured first sample. The steady offset d is the online adaptation term."""
    y, u, P, surv = batch
    e, a = ph_m.e_a(surv)
    n0 = (y[:, 0] + a) / e
    g_off = 0.0
    def rhs(n, ui, Pi):
        out = 0.0
        if mode in ("hybrid", "phys"): out = out + ph_m.f(n, Pi, ui)
        if mode in ("hybrid", "node"): out = out + net(ph_m.feats(n, ui, Pi))[..., 0] * 1e3
        return out
    d = -rhs(n0, u[:, 0], P[:, 0]).detach()
    n = n0; out = [y[:, 0]]
    h = DS / sub
    for i in range(y.shape[1] - 1):
        ui, Pi = u[:, i + 1], P[:, i + 1]  # the input over a step is the one active at its end sample
        for _ in range(sub):
            # exponential Euler: the scalar ODE is stiff at low load because the reservoir model has no ASE clamp
            f0 = rhs(n, ui, Pi) + d
            with torch.no_grad():
                z = torch.clamp((rhs(n + 1e-3, ui, Pi) - rhs(n, ui, Pi)) / 1e-3, max=-1.0, min=-2e6)
                phi = (torch.exp(z * h) - 1) / z
            n = torch.clamp(n + phi * f0, 0.02, 0.98)
        out.append(e * n - a)
    return torch.stack(out, 1)


def to_batch(D, idx):
    return (torch.as_tensor(D["y"][idx]), torch.as_tensor(D["u"][idx]), torch.as_tensor(D["P"][idx]), torch.as_tensor(D["surv"][idx]))


def train_ode(ph_m, D, n_tr, seed, mode, steps=400):
    torch.manual_seed(seed)
    net = mlp(4, 1, 48, 2)
    opt = torch.optim.Adam(net.parameters(), lr=2e-3)
    sch = torch.optim.lr_scheduler.CosineAnnealingLR(opt, steps)
    r = np.random.default_rng(seed)
    for it in range(steps):
        idx = r.integers(0, n_tr, 16)
        t0 = r.integers(0, D["y"].shape[1] - 120)
        b = to_batch(D, idx)
        b = (b[0][:, t0:t0 + 120], b[1][:, t0:t0 + 120], b[2][:, t0:t0 + 120], b[3])
        p = rollout(ph_m, net, b, mode)
        loss = ((p - b[0]) ** 2).mean()
        opt.zero_grad(); loss.backward(); nn.utils.clip_grad_norm_(net.parameters(), 5.0); opt.step(); sch.step()
    return net


def feats_lowd(D, idx):
    """Black box inputs: pump, total input, centroid plus first sample of the trace."""
    u, P = D["u"][idx], D["P"][idx]
    tot = P.sum(-1); c = (P * np.linspace(-1, 1, P.shape[-1])).sum(-1) / np.maximum(tot, 1e-12)
    y0 = D["y"][idx][:, :1]
    X = np.stack([u, tot * 1e3 / 5, c], -1)
    X0 = np.repeat(X[:, :1], X.shape[1], 1)
    return np.concatenate([X, X0, np.repeat(y0[..., None] / 20, X.shape[1], 1)], -1).astype(np.float32), (D["y"][idx] - y0)


def train_static(D, n_tr, seed, steps=3000):
    torch.manual_seed(seed); net = mlp(7, 1, 64, 3, zero_last=False)
    X, Y = feats_lowd(D, np.arange(n_tr)); X = torch.as_tensor(X.reshape(-1, 7)); Y = torch.as_tensor(Y.reshape(-1, 1))
    o = torch.optim.Adam(net.parameters(), lr=2e-3)
    for _ in range(steps):
        i = torch.randint(0, len(X), (1024,)); loss = ((net(X[i]) - Y[i]) ** 2).mean()
        o.zero_grad(); loss.backward(); o.step()
    return net


class LSTM(nn.Module):
    def __init__(s, ni=7, h=64):
        super().__init__(); s.r = nn.LSTM(ni, h, batch_first=True); s.o = nn.Linear(h, 1)

    def forward(s, x): return s.o(s.r(x)[0])[..., 0]


def train_lstm(D, n_tr, seed, steps=800):
    torch.manual_seed(seed); net = LSTM()
    X, Y = feats_lowd(D, np.arange(n_tr)); X, Y = torch.as_tensor(X), torch.as_tensor(Y)
    o = torch.optim.Adam(net.parameters(), lr=2e-3)
    for _ in range(steps):
        i = torch.randint(0, len(X), (16,)); loss = ((net(X[i]) - Y[i]) ** 2).mean()
        o.zero_grad(); loss.backward(); nn.utils.clip_grad_norm_(net.parameters(), 5.0); o.step()
    return net


class PINN(nn.Module):
    """Time marching PINN on one segment: n(tau) = n_s + tau net(tau, n_s, u, tot, c). Physics enters only through the loss."""

    def __init__(s):
        super().__init__(); s.f = mlp(5, 1, 64, 3, zero_last=False)

    def forward(s, tau, x):
        return x[:, 0] / 5 + 0.6 + tau * s.f(torch.cat([tau[:, None], x], 1))[:, 0] * 0.5


def train_pinn(ph_m, D, n_tr, seed, steps=4000, lam_r=1.0, seg=4):
    torch.manual_seed(seed); net = PINN()
    o = torch.optim.Adam(net.parameters(), lr=1.5e-3)
    sch = torch.optim.lr_scheduler.CosineAnnealingLR(o, steps)
    r = np.random.default_rng(seed)
    Tseg = seg * DS
    for _ in range(steps):
        i = r.integers(0, n_tr, 256); t = r.integers(0, D["y"].shape[1] - seg, 256)
        y0 = torch.as_tensor(D["y"][i, t]); y1 = torch.as_tensor(D["y"][i, t + seg])
        u = torch.as_tensor(D["u"][i, t + 1]); P = torch.as_tensor(D["P"][i, t + 1]); s = torch.as_tensor(D["surv"][i])
        e, a = ph_m.e_a(s)
        n0 = (y0 + a) / e; n1 = (y1 + a) / e
        x = ph_m.feats(n0, u, P)
        pred1 = net(torch.ones(256), x)
        tau = torch.rand(256, requires_grad=True)
        nc = net(tau, x)
        dn = torch.autograd.grad(nc.sum(), tau, create_graph=True)[0] / Tseg
        res = (dn - ph_m.f(nc, P, u)) / 2e3
        loss = (((pred1 - n1) * e) ** 2).mean() + lam_r * (res ** 2).mean()
        o.zero_grad(); loss.backward(); nn.utils.clip_grad_norm_(net.parameters(), 5.0); o.step(); sch.step()
    return net, seg


@torch.no_grad()
def pinn_roll(ph_m, net, seg, b):
    y, u, P, s = b
    e, a = ph_m.e_a(s); n = (y[:, 0] + a) / e; out = [y[:, 0]]
    N = y.shape[1]; res = torch.zeros_like(y); res[:, 0] = y[:, 0]
    for i in range(0, N - 1, seg):
        x = ph_m.feats(n, u[:, i + 1], P[:, i + 1])
        for j in range(1, seg + 1):
            if i + j < N: res[:, i + j] = e * net(torch.full((len(n),), j / seg), x) - a
        n = torch.clamp(net(torch.ones(len(n)), x), 0.02, 0.98)
    return res


def score(p, y):
    e = p - y
    return dict(rmse=float(np.sqrt((e ** 2).mean())), mae=float(np.abs(e).mean()), peak=float(np.abs(e).max(1).mean()))


def export(net):
    L = [m for m in net if isinstance(m, nn.Linear)]
    return [(m.weight.detach().numpy().T.astype(np.float64), m.bias.detach().numpy().astype(np.float64)) for m in L]


def job(a):
    band, name, n_tr, seed = a
    Dtr = dict(np.load(f"data/trans_{band}_train.npz"))
    Dte = dict(np.load(f"data/trans_{band}_test.npz"))
    gff = Dtr["gff"]
    pm = Phys(band, gff)
    bte = to_batch(Dte, np.arange(len(Dte["y"])))
    drops = {}
    for d in (50, 80): drops[d] = dict(np.load(f"data/trans_{band}_drop{d}.npz"))
    t0 = time.time()
    if name in ("hybrid", "node", "phys"):
        net = train_ode(pm, Dtr, n_tr, seed, name) if name != "phys" else None
        fn = lambda b: rollout(pm, net, b, name).detach().numpy()
        with torch.no_grad(): pass
    elif name == "mlp":
        net = train_static(Dtr, n_tr, seed)
        fn = lambda b: None
    elif name == "lstm":
        net = train_lstm(Dtr, n_tr, seed); fn = lambda b: None
    elif name == "pinn":
        net, seg = train_pinn(pm, Dtr, n_tr, seed); fn = lambda b: pinn_roll(pm, net, seg, b).numpy()
    def pred(D):
        idx = np.arange(len(D["y"]))
        if name == "mlp":
            X, _ = feats_lowd(D, idx)
            with torch.no_grad(): return (net(torch.as_tensor(X.reshape(-1, 7))).numpy().reshape(X.shape[:2]) + D["y"][idx][:, :1])
        if name == "lstm":
            X, _ = feats_lowd(D, idx)
            with torch.no_grad(): return net(torch.as_tensor(X)).numpy() + D["y"][idx][:, :1]
        return fn(to_batch(D, idx))
    tt = time.time() - t0
    t0 = time.perf_counter()
    P = pred(Dte); tinf = (time.perf_counter() - t0) / (Dte["y"].shape[0] * Dte["y"].shape[1]) * 1e3
    R = dict(band=band, name=name, n_tr=n_tr, seed=seed, train_s=tt, infer_ms_per_sample=tinf, test=score(P, Dte["y"]))
    for d, Dd in drops.items():
        Pd = pred(Dd); R[f"drop{d}"] = score(Pd, Dd["y"])
        if seed == 0 and n_tr == 128:
            np.savez(f"sonuclar/trace_{band}_{name}_{d}.npz", p=Pd[:8], y=Dd["y"][:8])
    if name == "node" and n_tr == 128:
        np.savez(f"sonuclar/nodetwin_{band}_{seed}.npz", **{f"p{i}": v for i, v in enumerate(sum([list(x) for x in export(net)], []))})
    if name == "hybrid" and n_tr == 128:
        np.savez(f"sonuclar/twin_{band}_{seed}.npz", **{f"p{i}": v for i, v in enumerate(sum([list(x) for x in export(net)], []))})
        np.savez(f"sonuclar/test_pred_{band}_{seed}.npz", p=P)
        Pc = pred(dict(np.load(f"data/trans_{band}_cal.npz"))); np.savez(f"sonuclar/cal_pred_{band}_{seed}.npz", p=Pc)
    print(band, name, n_tr, seed, {k: round(v, 3) for k, v in R["test"].items()}, "drop80", round(R["drop80"]["rmse"], 3), "t", int(tt), flush=True)
    return R


def gen_all(band):
    rng = np.random.default_rng(7)
    _, _, _, _ = (None,) * 4
    p, _, _, _ = sim.make_stage(1, band, spread=0.0, rng=rng)
    gff = p.gff_db[0]
    for name, A, seed, kw in (("train", 128, 11, {}), ("cal", 32, 12, {}), ("test", 64, 13, {}),
                              ("drop50", 32, 14, dict(fixed_drop=0.5)), ("drop80", 32, 15, dict(fixed_drop=0.8))):
        t = time.time(); D = gen_traces(band, A, seed, **kw)
        np.savez(f"data/trans_{band}_{name}.npz", gff=gff, **D); print(band, name, D["y"].shape, round(time.time() - t, 1), flush=True)


if __name__ == "__main__":
    ctx = get_context("spawn")
    if not os.path.exists("data/trans_L_drop80.npz"):
        with ctx.Pool(2) as p: p.map(gen_all, ["C", "L"])
    jobs = []
    for band in ("C", "L"):
        jobs += [(band, "phys", 128, 0)]
        for n_tr in (16, 128):
            for name in ("hybrid", "node", "pinn", "lstm", "mlp"):
                for s in range(5 if (name == "hybrid" and n_tr == 128) else 3):
                    jobs.append((band, name, n_tr, s))
    with ctx.Pool(14) as p: res = list(p.imap_unordered(job, jobs))
    json.dump(res, open("sonuclar/transient.json", "w"))
